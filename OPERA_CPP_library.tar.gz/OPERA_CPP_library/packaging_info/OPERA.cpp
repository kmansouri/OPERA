//
// MATLAB Compiler: 5.0 (R2013b)
// Date: Wed Dec  7 12:12:12 2016
// Arguments: "-B" "macro_default" "-W" "cpplib:OPERA" "-T" "link:lib" "-d"
// "/home/kmansour/Documents/work/OPERA/Modeling/13Prop/OPERA/for_testing" "-v"
// "/home/kmansour/Documents/work/OPERA/Modeling/13Prop/OPERA.m"
// "class{Class1:/home/kmansour/Documents/work/OPERA/Modeling/13Prop/OPERA.m}"
// "-a" "/home/kmansour/Documents/work/OPERA/Modeling/13Prop/13models.mat" "-a"
// "/home/kmansour/Documents/work/OPERA/Modeling/13Prop/help.txt" 
//

#include <stdio.h>
#define EXPORTING_OPERA 1
#include "OPERA.h"

static HMCRINSTANCE _mcr_inst = NULL;


#ifdef __cplusplus
extern "C" {
#endif

static int mclDefaultPrintHandler(const char *s)
{
  return mclWrite(1 /* stdout */, s, sizeof(char)*strlen(s));
}

#ifdef __cplusplus
} /* End extern "C" block */
#endif

#ifdef __cplusplus
extern "C" {
#endif

static int mclDefaultErrorHandler(const char *s)
{
  int written = 0;
  size_t len = 0;
  len = strlen(s);
  written = mclWrite(2 /* stderr */, s, sizeof(char)*len);
  if (len > 0 && s[ len-1 ] != '\n')
    written += mclWrite(2 /* stderr */, "\n", sizeof(char));
  return written;
}

#ifdef __cplusplus
} /* End extern "C" block */
#endif

/* This symbol is defined in shared libraries. Define it here
 * (to nothing) in case this isn't a shared library. 
 */
#ifndef LIB_OPERA_C_API
#define LIB_OPERA_C_API /* No special import/export declaration */
#endif

LIB_OPERA_C_API 
bool MW_CALL_CONV OPERAInitializeWithHandlers(
    mclOutputHandlerFcn error_handler,
    mclOutputHandlerFcn print_handler)
{
    int bResult = 0;
  if (_mcr_inst != NULL)
    return true;
  if (!mclmcrInitialize())
    return false;
    {
        mclCtfStream ctfStream = 
            mclGetEmbeddedCtfStream((void *)(OPERAInitializeWithHandlers));
        if (ctfStream) {
            bResult = mclInitializeComponentInstanceEmbedded(   &_mcr_inst,
                                                                error_handler, 
                                                                print_handler,
                                                                ctfStream);
            mclDestroyStream(ctfStream);
        } else {
            bResult = 0;
        }
    }  
    if (!bResult)
    return false;
  return true;
}

LIB_OPERA_C_API 
bool MW_CALL_CONV OPERAInitialize(void)
{
  return OPERAInitializeWithHandlers(mclDefaultErrorHandler, mclDefaultPrintHandler);
}

LIB_OPERA_C_API 
void MW_CALL_CONV OPERATerminate(void)
{
  if (_mcr_inst != NULL)
    mclTerminateInstance(&_mcr_inst);
}

LIB_OPERA_C_API 
void MW_CALL_CONV OPERAPrintStackTrace(void) 
{
  char** stackTrace;
  int stackDepth = mclGetStackTrace(&stackTrace);
  int i;
  for(i=0; i<stackDepth; i++)
  {
    mclWrite(2 /* stderr */, stackTrace[i], sizeof(char)*strlen(stackTrace[i]));
    mclWrite(2 /* stderr */, "\n", sizeof(char)*strlen("\n"));
  }
  mclFreeStackTrace(&stackTrace, stackDepth);
}


LIB_OPERA_C_API 
bool MW_CALL_CONV mlxOPERA(int nlhs, mxArray *plhs[], int nrhs, mxArray *prhs[])
{
  return mclFeval(_mcr_inst, "OPERA", nlhs, plhs, nrhs, prhs);
}

LIB_OPERA_CPP_API 
void MW_CALL_CONV OPERA(int nargout, mwArray& res, const mwArray& varargin)
{
  mclcppMlfFeval(_mcr_inst, "OPERA", nargout, 1, -1, &res, &varargin);
}

LIB_OPERA_CPP_API 
void MW_CALL_CONV OPERA(int nargout, mwArray& res)
{
  mclcppMlfFeval(_mcr_inst, "OPERA", nargout, 1, 0, &res);
}

