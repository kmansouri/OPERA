MATLAB Compiler

1. Application and Matlab Runtime Deployment 

. Run MyAppInstaller_web.exe to properly deploy OPERA (by default in C:\Program Files).
  This will also install MATLAB Runtime version 9.1 (R2016b). This doesn't add the app to your %PATH%.  

. Or download the Windows 64-bit version of the MATLAB Runtime for R2016b 
from the MathWorks Web site by navigating to

   http://www.mathworks.com/products/compiler/mcr/index.html
   
   
For more information about the MATLAB Runtime and the MATLAB Runtime installer, see 
Package and Distribute in the MATLAB Compiler documentation  
in the MathWorks Documentation Center.    


NOTE: You will need administrator rights to run MyAppInstaller. 


2. Application use

Files available for use by the Standalone App
================================
-This readme file 
-OPERA.exe to run the app from command prompt (cmd)
-Shortcut for OPERA.exe use this if you want to ru the app by double cliquing from Desktop
 (or other location). This will run the app in your %HOMEPATH% as the working directory (can be changed from the shortcut properties)
-help.txt explains the different input and output arguments. Can be accessed from the app (-h command).
-splash.png the splash screen shown while loading the app. Can be renamed or deleted if not needed.
-icons can be used for creating new shortcuts.
-PaDEL-Descriptor jar and librairies (need to be in the working directory in order to run predictions from structures).
-Sample_50.csv, Sample_50.sdf, Salt_info.csv Sample files for testing

3. Definitions

For information on deployment terminology, go to 
http://www.mathworks.com/help. Select MATLAB Compiler >   
Getting Started > About Application Deployment > 
Deployment Product Terms in the MathWorks Documentation 
Center.





