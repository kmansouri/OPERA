function res=OPERA(varargin)


%
%
%      OPERA models for physchem and environmental fate propeties.
%                       Version 1.02 (August 2016)
%
%OPERA is a command line application developed in Matlab (version 8.2) providing QSAR models predictions as well as 
%applicability domain and accuracy assessment. All models are weighted kNN built on curated data from public domain. 
%Molecular descriptors are calculated using PaDEL software.
%Usage: ./run_OPERA.sh <mcr_directory> <argument_list>
%By default, all endpoints will be calculated.
%Examples: 
%./run_OPERA.sh /mathworks/home/application/v82 -s Sample_50.sdf -o predictions.csv -a -x -v 2
%./run_OPERA.sh $LD_LIBRARY_PATH -d Sample_50.csv -o predictions.txt -e logP BCF -n -v 1
%
%Input: 
%  -s, --SDF, --MOL, --SMI  Structure file containing the molecule(s) to be 
%                           predicted. IDs will be assigned if the file does not contain molecule names.
%                           Molecular descriptors will be calculated using PaDEL software.
%  -d, --Descriptors        pre-calculated PaDEL descriptors in csv file. If the first column is not 
%                           "Name" as the standard PaDEL output, molecule IDs will be assinged.
%  -m, --Mat, --ascii       Matlab matrix or ascii file containing PaDEL descriptors.
%  -i, --MolID              Molecule names in csv file.
%  -t, --SaltInfo           Salt IDs to improve melting point predictions. List provided in Salts.xls
%  -l, --Labels             Descriptor labels. Necessary if the descriptor file does not contain labels 
%                           or contains more than the 1444 PaDEL 2D descriptors.
%
%Output:
%  -o, --Output             Output file containing the predictions, applicability domain and accuracy 
%                           information. File extension could be csv or txt. The output will contain by default: 
%                           Molecule ID, predicted value (pred), Applicability domain (AD), Similarity index 
%                           (Sim_index) and accuracy estimate (Conf_index).
%  -n, --Neighbors          Add 5 nearest neighbors from training set (CAS, InCHiKeys, Observed and predicted values)
%  -O, --FullOutput         Output file containing all prediction details and used descriptors in csv format.
%  -x, --Seperate           Separate output file for each endpoint. 
%
%Miscellaneous:
%  -v, --Verbose            Verbose level: 0=silent (default), 1=minimum details, %  2=full details.
%  -a, --All                All endpoints to be calculated. Default.
%  -c, --Clean              Clean temporary files (generated during descriptor calculation.)
%  -e, --Endpoint           List endpoints to be calculated (case insensitive). 'BCF'/'logBCF','BP','logP','MP',
%                           'VP'/'logVP','WS', 'AOH', 'BioDeg', 'RB'/'ReadyBiodeg','HL'/'logHL','KM'/'logKM',
%                           'KOA','Koc'/'logKoc'. Space separated.
%  -RB, -logP, -BCF...      Endpoints to be calculated.
%  -h, --Help               Display this help file and exit.
%  -V, --Version            Version of the application
%  
%
%
%
%Developed by:
%Kamel Mansouri
%mansourikamel@gmail.com
%
%Developed at: 
%National Center of Computational Toxicology
%United States Environmental Protection Agency
%109 T.W. Alexander Drive 
%Research Triangle Park, NC 27711
%
%For more information about the models and the data:
%[1] Mansouri, K.; Grulke, C. M.; Richard, A. M.; Judson, R. S.; and
%Williams, A. j. An Automated curation procedure for adressing chemistry
%related errors and inconsistencies in public domain datasets used in QSAR
%modeling. SAR and QSAR in Environmental Research.
%[2] Mansouri, K.; Grulke, C. M.; Richard, A. M.; Judson, R. S.; and
%Williams, A. J. OPERA: A QSAR tool for physicochemical properties and environmental fate predictions
%[3] Yap CW (2011). PaDEL-Descriptor: An open source software to calculate molecular descriptors and fingerprints. 
%Journal of Computational Chemistry. 32 (7): 1466-1474
%[4] iCSS Chemistry Dashboard accessible at: https://comptox.epa.gov


train=load ('13models.mat', '-mat');
%train=load ('train_LogP_knnr9.mat', '-mat');
%train=load ('13models.mat', '-mat');


FileOut='results.txt';
Xlabels=train.labels;
verbose=0;InputMatrix=0;
importedNames=0;    
input=0;
structure=0;
clean=0;
printtDesc=0;
sep=0;
all=1;
prop={};
salt=0;
help=0;
e=0;
i=1;
neighbors=0;


    
if nargin>0
    while i<=length(varargin)
        if  strcmpi('--descriptors',varargin{i})| strcmpi('-d',varargin{i})| strcmpi('--desc',varargin{i})
          InputDesc=varargin{i+1};
          input=1;
          i=i+2;
          continue
        elseif strcmpi('--mat',varargin{i}) | strcmpi('--ascii',varargin{i})| strcmp('-m',varargin{i})
            InputDesc=varargin{i+1};
          InputMatrix=1;
          input=1;
          i=i+2;
          continue
        elseif strcmpi('--MolID',varargin{i})| strcmp('-i',varargin{i})
            MolID=varargin{i+1};
            MoleculeNames=importfile(MolID);
            importedNames=1;
            i=i+2;
          continue
        elseif  strcmpi('--labels',varargin{i}) | strcmp('-l',varargin{i})
            labels=varargin{i+1};
            Xlabels=importfile(labels);
            i=i+2;
          continue
        elseif strcmpi('--structure',varargin{i}) | strcmpi('--sdf',varargin{i})| strcmpi('--smiles',varargin{i})| strcmpi('--smi',varargin{i})| strcmpi('-s',varargin{i})| strcmpi('--mol',varargin{i})
            StructureFile=varargin{i+1};
            InputDesc='PadelDesc.csv';
            structure =1; 
            input=1;
            %clean=1;
            i=i+2;
          continue
        elseif strcmpi('--out',varargin{i}) | strcmpi('--fullOutput',varargin{i})| strcmpi('-o',varargin{i})
            FileOut=varargin{i+1};
            if strcmpi('--fullOutput',varargin{i})| strcmp('-O',varargin{i})
                printtDesc=1;
                neighbors=1;
            end
            i=i+2;
          continue
        elseif strcmp('-v',varargin{i}) | strcmpi('--verbose',varargin{i})
            verbose=varargin{i+1};
            if ischar(verbose)
                verbose=str2double(verbose);
            end
            i=i+2;
          continue
        elseif strcmpi('--Clean',varargin{i})| strcmp('-c',varargin{i})
             clean=1; 
             i=i+1;
          continue
        elseif strcmpi('--Neighbors',varargin{i})| strcmp('-n',varargin{i})
             neighbors=1; 
             i=i+1;
          continue
        elseif strcmpi('--salt',varargin{i}) | strcmpi('--saltInfo',varargin{i})| strcmp('-t',varargin{i})
            salt=1;
            FileSalt=varargin{i+1};
            i=i+2;
          continue
        elseif strcmpi('--sep',varargin{i}) | strcmpi('--separate',varargin{i})| strcmp('-x',varargin{i})
             sep=1; 
             i=i+1;
          continue
        elseif strcmpi('-All',varargin{i})| strcmp('-a',varargin{i})
             all=1; 
             i=i+1;
          continue
        elseif strcmp('-e',varargin{i})| strcmpi('--endpoint',varargin{i})
            all=0;
            e=1;
            i=i+1;
          continue
        elseif strcmpi('BCF',varargin{i}) | strcmpi('BP',varargin{i})| strcmpi('LogP',varargin{i})| strcmpi('MP',varargin{i})| strcmpi('VP',varargin{i})| strcmpi('WS',varargin{i})...
                | strcmpi('logWS',varargin{i})| strcmpi('logVP',varargin{i})| strcmpi('LogBCF',varargin{i})| strcmpi('AOP',varargin{i})| strcmpi('BioHC',varargin{i})...
                | strcmpi('Biowin',varargin{i})| strcmpi('RB',varargin{i})| strcmpi('HL',varargin{i})| strcmpi('KM',varargin{i})| strcmpi('KOA',varargin{i})| strcmpi('PC',varargin{i})...
                | strcmpi('KOC',varargin{i})| strcmpi('LogKOC',varargin{i})| strcmpi('LogKM',varargin{i})| strcmpi('LogHL',varargin{i})| strcmpi('BioDeg',varargin{i})| strcmpi('AOH',varargin{i})...
                | strcmpi('ReadyBiodeg',varargin{i})
            if e==1
                prop=[prop varargin{i}];
            else
                error('ERROR. Check input arguments or type -h, --help for more info.')
            end
            i=i+1;
          continue
            
        elseif strcmpi('-BCF',varargin{i}) | strcmpi('-BP',varargin{i})| strcmpi('-LogP',varargin{i})| strcmpi('-MP',varargin{i})| strcmpi('-VP',varargin{i})| strcmpi('-WS',varargin{i})...
                | strcmpi('-logWS',varargin{i})| strcmpi('-logVP',varargin{i})| strcmpi('-LogBCF',varargin{i})| strcmpi('-AOP',varargin{i})| strcmpi('-BioHC',varargin{i})...
                | strcmpi('-Biowin',varargin{i})| strcmpi('-RB',varargin{i})| strcmpi('-HL',varargin{i})| strcmpi('-KM',varargin{i})| strcmpi('-KOA',varargin{i})| strcmpi('-PC',varargin{i})...
                | strcmpi('-KOC',varargin{i})| strcmpi('-LogKOC',varargin{i})| strcmpi('-LogKM',varargin{i})| strcmpi('-LogHL',varargin{i})| strcmpi('-BioDeg',varargin{i})| strcmpi('-AOH',varargin{i})...
                | strcmpi('-ReadyBiodeg',varargin{i})
             all=0;
             prop=[prop strrep(varargin{i},'-','')];
             i=i+1;
          continue
        elseif strcmpi('--help',varargin{i})| strcmp('-h',varargin{i})
            help=1;
            type('help.txt')
            i=i+1;
          continue
        elseif strcmp('-V',varargin{i})| strcmpi('--version',varargin{i})
            fprintf(1,'Version 1.02 \n');
            help=1;
            i=i+1;
          %continue
         else
             error('ERROR. Check input arguments or type -h, --help for more info.')
            
        end

    end
else
error('MyComponent:incorrectType',...
    'ERROR. Not enough arguments. \nUsage: OPERA [OPTION]... <Input> <output>... \nType -h, --help for more info.')
   
%fprintf(2,'Not enough arguments \n');
%return
end

if verbose==0 | isdeployed
    warning('off','MATLAB:codetools:ModifiedVarnames');
else
    warning('on','MATLAB:codetools:ModifiedVarnames');
end


% if help==1
%     return
%     %('End help file!')
% end
% % else
if help==0

    
if input==0 %&& help==0 %&&  structure ==0;
 error('MyComponent:incorrectType',...
     'ERROR. You must at least enter an input file. \nUsage: OPERA [OPTION]... <Input> <output>... \nType -h, --help for more info.')
 %   fprintf(2,'You must at least enter an input file \n');
 %   return
end


if all==1
    prop= {'LogBCF','BP','LogP','MP','VP','WS', 'AOH', 'BioDeg', 'ReadyBiodeg','HL','KM','KOA','Koc'};
        if verbose >0
            fprintf(1,'All 13 endpoints will be calculated\n');
        end
else
    if verbose >0
        if size(prop(:),1)>1
            endpoints=strjoin(prop(1:size(prop(:),1)-1),',  ');
            fprintf(1,'Endpoints to be calculated: %s and %s\n',endpoints,prop{end});
        else
            fprintf(1,'Endpoint to be calculated: %s\n',prop{:});
        end
            
    end
end


if structure==1
    if verbose ==1
        fprintf(1,'PaDEL calculating 2D descriptors...\n');
        [status,cmdout] =system (['java -Djava.awt.headless=true -jar PaDEL-Descriptor.jar -2d -retainorder -dir ' StructureFile ' -file PadelDesc.csv > PaDELlogfile.log']);
        if clean==1 
            delete('PaDELlogfile.log'); 
        end
    elseif verbose ==2
        fprintf(1,'PaDEL calculating 2D descriptors...\n');
        status =system (['java -Djava.awt.headless=true -jar PaDEL-Descriptor.jar -2d -retainorder -dir ' StructureFile ' -file PadelDesc.csv']);
    else
        [status,cmdout] =system (['java -Djava.awt.headless=true -jar PaDEL-Descriptor.jar -2d -retainorder -dir ' StructureFile ' -file PadelDesc.csv > PaDELlogfile.log']);
    end
    
    if status==0 && verbose==1 && isempty(cmdout)
        fprintf(1,'End of descriptors calculation: ');
        [status2, numlines] = system( ['wc -l ', 'PadelDesc.csv'] );
        fprintf(1, '%d molecules calculated.\n',str2double(strrep(numlines,' PadelDesc.csv',''))-1);
 
        %Windows OS: store the below two lines in countlines.pl      
        %while (<>) {};
        %print $.,"\n";
        %Then to make a matlab call to count the lines for file XYZ.csv
        %numlines = str2num( perl('countlines.pl', 'XYZ.csv') );
        
    elseif status==0 && verbose==1 && ~isempty(cmdout)
        disp(cmdout);
    end
        
end


    
%errmsg='Cannot write to output file \n';



ext=FileOut(length(FileOut)-3:end);
if sep==1
    outputname=cell(size(prop));
    %output=zeros(size(prop));
    
    FileOut=strrep(FileOut,ext,'');
   
     for i=1:length(prop)
%         FileOut(i)=[FileOut prop(i) ext] 
        outputname{i}=strrep(strjoin([FileOut '_' prop(i) ext]),' ', '');
        [output(i),errmsg]=fopen(outputname{i},'w');
     end
     FileOut=outputname;
else
 
    [output,errmsg]=fopen(FileOut,'w');
end





if verbose>0 && ~isempty(errmsg)
   error(errmsg)
    % disp(errmsg);
  %  return
end

if InputMatrix==1
    if verbose> 0
        disp('Loading matrix of descriptors...');
    end
    load(InputDesc);
    Xin=eval(InputDesc(1:length(InputDesc)-4));
    if importedNames==0 && size(Xin,1)==1444
        %MoleculeNames=num2cell(1:1:size(Xin,1))';
        for i=1:size(Xin,1)
            MoleculeNames{i,1}=strcat('M',num2str(i));
        end
%         if verbose>0
%             disp(' default PaDEL descriptor names considered...\n');
%         end
    else
        for i=1:size(Xin,1)
            MoleculeNames{i,1}=strcat('M',num2str(Xin(i)));
        end
        Xin(:,1)=[];
    end
else
    if verbose> 0
        disp('Loading csv file of descriptors and headers...');
    end
    
    %Xin=dataset('File',InputDesc,'delimiter',',');
    Xin=readtable(InputDesc,'delimiter',',');
    %Xlabels=Xin.Properties.VarNames;
    Xlabels=Xin.Properties.VariableNames;
    %Xin=dataset2table(Xin);
    if strcmpi(Xlabels{1},'Name')
        if verbose> 1
            disp('Molecule names found in input file.');
        end
            
        Xlabels=Xlabels(2:end);
        Names=Xin.Name;
        if isnumeric(Names)
            
            for i=1:size(Xin,1)
                MoleculeNames{i,1}=strcat('M',num2str(Names(i)));
            end
        else
            MoleculeNames=Names;

            %MoleculeID=num2cell(MoleculeNames);

        end
        %Xin=Xin{:,2:end};
        Xin=Xin(:,2:end);
    else
        
        if verbose> 1
            disp('Molecule names not found in input file. Generated IDs will be assigned.');
        end   
        %Xin=Xin{:,:};
        %Xin=Xin(:,:);
        
        for i=1:size(Xin,1)
            MoleculeNames{i,1}=strcat('M',num2str(i));
        end
    end
        
        i=1;
        Temp=zeros(size(Xin));
        if verbose> 0
            disp('Checking loaded variables.');
        end
        while i<=length(Xlabels)
            if cellfun(@ischar,table2cell(Xin(1,i)))
              Temp(:,i)=str2double(table2cell(Xin(:,i)));
            else
                    
                Temp(:,i)=Xin{:,i};
            end
                i=i+1;
        end
    

    clear('Xin');
    Xin=Temp;
    clear('Temp');
    
end

if salt==1
    if verbose> 0
            disp('Reading file with salt information.');
    end
    SaltIndex=readtable(FileSalt,'delimiter',',');
%     if strcmpi(SaltIndex{1},'Name')
%         SaltIndex=SaltIndex(
    if size(SaltIndex,1)==size(Xin,1)        
            if cellfun(@ischar,table2cell(SaltIndex(1,end)))
              Temp(:,:)=str2double(table2cell(SaltIndex(:,end)));
            else
                    
                Temp(:,:)=SaltIndex{:,end};
            end
    
        clear('SaltIndex');
        SaltIndex=Temp;
        clear('Temp'); 
    else
        error('ERROR. The number of compounds must be the same in both files.')
        %fprintf(2,'Number of compounds must be the same in both files. \n');
        %return
    end
     
    %res.SaltID=SaltIndex;
end


if clean==1 && structure==1
        delete('PadelDesc.csv');
end


if verbose>0
    fprintf(1,'The number of input molecules is: %d \n',size(Xin,1));
    disp(['The number of loaded descriptors is: ', num2str(length(Xlabels))]);
    
end
            



DescMat=[];
DescNames={};

for j=1:length(prop)
    switch lower(prop{j})
        
        %Predict logP values
        case 'logp'
            
            
            Desc=train.LogP.Desc;

            
            if verbose>0
                disp('Predicting LogP values...');
                disp(['Considered descriptors for LogP model: ', num2str(length(Desc))]);
                
            end
            
            if strcmpi(ext,'.txt') && sep==0
                fprintf(output,'\n\n\t\t\t\t\t Predicting LogP values... \n\n			==============================================================n\n');
            end
            
            
            Xtest=zeros(size(Xin,1),length(Desc));
            
            for i=1:length(Desc)
                for l=1:length(Xin(1,:))
                    if strcmp(Desc(i),Xlabels(l))
                        Xtest(:,i)=Xin(:,l);
                        break;
                    end
                end
            end
            
            pred = nnrpred(Xtest,train.LogP.model.set.train,train.LogP.model.set.y,train.LogP.model.set.K,train.LogP.model.set.dist_type,train.LogP.model.set.param.pret_type);
            
            res.MoleculeID=MoleculeNames;
            
            res.LogP_pred(:,1)=pred.y_pred_weighted;
            AD=classical_leverage(train.LogP.model.set.train,Xtest,'auto');
            res.AD_LogP=abs(AD.inorout-1)';
            
%             res.Sim_index1=1./(1+median(pred.dc,2));             
%             if isnan(res.Sim_index1)
%                 res.Sim_index1(isnan(res.Sim_index1))=0;
%             end
            
             %res.Sim_index1=1./(1+nanmedian(pred.dc,2));
            
            
            res.Sim_index_LogP=zeros(size(Xtest,1),1);
%             res.Conf_index1=zeros(size(Xtest,1),1);
            res.Conf_index_LogP=zeros(size(Xtest,1),1);
            
%             res.dc=pred.dc;
%             res.w=pred.w;
            LogP_CAS_neighbor=cell(size(Xtest,1),5);
            LogP_InChiKey_neighbor=cell(size(Xtest,1),5);
            LogP_Exp_neighbor=zeros(size(Xtest,1),5);
            LogP_pred_neighbor=zeros(size(Xtest,1),5);

            
            for i=1:size(Xtest(:,1))
                LogP_CAS_neighbor(i,:)=train.LogP.CAS(pred.neighbors(i,:));
                LogP_InChiKey_neighbor(i,:)=train.LogP.InChiKey(pred.neighbors(i,:));
                LogP_Exp_neighbor(i,:)=train.LogP.model.set.y(pred.neighbors(i,:));
                LogP_pred_neighbor(i,:)=train.LogP.model.yc_weighted(pred.neighbors(i,:));
                
                res.Sim_index_LogP(i,1)=1./(1+pred.dc(i,~isnan(pred.dc(i,:)))*pred.w(i,~isnan(pred.dc(i,:)))');
                
                if isempty(find(~isnan(pred.dc(i,:)), 1))
                    res.Sim_index_LogP(i)=0;
                    res.AD_LogP(i)=0;
                end
                
                res.Conf_index_LogP(i,1)=1/(1+sqrt(((LogP_Exp_neighbor(i,:)-LogP_pred_neighbor(i,:)).^2)*pred.w(i,:)'));

                
%                 rmse=calc_reg_param(res.LogP_Exp_neighbor(i,:),res.LogP_pred_neighbor(i,:));
%                 res.Conf_index1(i,1)=1/(1+rmse.RMSEC);
                
                %res.Conf_index(i,1)=1/(1+sqrt(sum(diag((res.LogP_Exp_neighbor(i,:)-res.LogP_pred_neighbor(i,:))*pred.w(i,:)').^2)));
                
                if neighbors==1
                    res.LogP_CAS_neighbor(i,:)=LogP_CAS_neighbor(i,:);
                    res.LogP_InChiKey_neighbor(i,:)=LogP_InChiKey_neighbor(i,:);
                    res.LogP_Exp_neighbor(i,:)=LogP_Exp_neighbor(i,:);
                    res.LogP_pred_neighbor(i,:)=LogP_pred_neighbor(i,:);
                end
                    
                
                             
                if strcmpi(ext,'.txt') && sep==1
                    
                    
                    %res.Xtest=Xtest;
                    fprintf(output(j),'\t Molecule %s:\n', res.MoleculeID{i});
                    fprintf(output(j),'LogP predicted= %.3f\n', res.LogP_pred(i));
                    if res.AD_LogP(i)==1
                        fprintf(output(j),'AD: inside\n');
                    else
                        fprintf(output(j),'AD: outside\n');
                    end
                    fprintf(output(j),'Sim_index= %.2f\n', res.Sim_index_LogP(i));
                    fprintf(output(j),'Conf_index= %.2f\n', res.Conf_index_LogP(i));
                    %CAS=strjoin(res.LogP_CAS_neighbor(i,1:5),',\t');
                    %calc=strjoin(num2cell(res.LogP_pred_neighbor(i,1:5)),', ');
                    %exp=strjoin(num2cell(res.LogP_Exp_neighbor(i,1:5)),', ');
                    %CAS=strrep([res.CAS_neighbors(i,1:5)],' ',', ');
                    if neighbors==1
                        fprintf(output(j),'CAS of the %i nearest neighbors:%15s,%15s,%15s,%15s,%15s\n',train.LogP.model.set.K,res.LogP_CAS_neighbor{i,1:5});
                        fprintf(output(j),'Exp of the %i nearest neighbors:%15.3f,%15.3f,%15.3f,%15.3f,%15.3f\n',train.LogP.model.set.K, res.LogP_Exp_neighbor(i,1:5));
                        fprintf(output(j),'Pred of the %i nearest neighbors:%14.3f,%15.3f,%15.3f,%15.3f,%15.3f\n\n',train.LogP.model.set.K, res.LogP_pred_neighbor(i,1:5));
                    end
                    
                elseif strcmpi(ext,'.txt') && sep==0
                                
                    %res.Xtest=Xtest;
                    fprintf(output,'\t Molecule %s:\n',res.MoleculeID{i});
                    fprintf(output,'LogP predicted= %.3f\n', res.LogP_pred(i));
                    if res.AD_LogP(i)==1
                        fprintf(output,'AD: inside\n');
                    else
                        fprintf(output,'AD: outside\n');
                    end
                    fprintf(output,'Sim_index= %.2f\n', res.Sim_index_LogP(i));
                    fprintf(output,'Conf_index= %.2f\n', res.Conf_index_LogP(i));
                    %CAS=strjoin(res.LogP_CAS_neighbor(i,1:5),',\t');
                    %CAS=strrep([res.CAS_neighbors(i,1:5)],' ',', ');
                    if neighbors==1
                        fprintf(output,'CAS of the %i nearest neighbors:%15s,%15s,%15s,%15s,%15s\n',train.LogP.model.set.K, res.LogP_CAS_neighbor{i,1:5});
                        fprintf(output,'Exp of the %i nearest neighbors:%15.3f,%15.3f,%15.3f,%15.3f,%15.3f\n',train.LogP.model.set.K, res.LogP_Exp_neighbor(i,1:5));
                        fprintf(output,'Pred of the %i nearest neighbors:%14.3f,%15.3f,%15.3f,%15.3f,%15.3f\n\n',train.LogP.model.set.K, res.LogP_pred_neighbor(i,1:5));
                    end
                end
            end
            
            
            if sep==1 && strcmpi(ext,'.csv')
                T=struct2table(res);
                if printtDesc==1
                    Xtest=array2table(Xtest,'VariableNames',Desc);
                    
                    T=[T Xtest];
                end
                writetable(T,FileOut{j},'Delimiter',',');%,'QuoteStrings',true);
                fclose(output(j));
                
            elseif sep==0 && printtDesc==1 && strcmpi(ext,'.csv')
                
                                
                Xtest(:,ismember(Desc,DescNames))=[];
            
                Desc(ismember(Desc,DescNames))=[];
                
                DescNames=[DescNames Desc];
                
                DescMat=[DescMat Xtest];
                
     
            end
         
          if sep==1
              resf.LogP=res;
              clear('res');
          end
            
         %Predict MP values
         case 'mp'
            
            
            Desc=train.MP.Desc;
            
            
            if verbose>0
                disp('Predicting MP values...');
                disp(['Considered descriptors for MP model: ', num2str(length(Desc))]);
                if salt==1
                    disp('Salt information will be considered in the predictions');
                end
                
            end
            
            if strcmpi(ext,'.txt') && sep==0
                fprintf(output,'\n\n\t\t\t\t\t Predicting MP values... \n\n			============================================================== \n\n');
            end
            
            Xtest=zeros(size(Xin,1),length(Desc));
            
            for i=1:length(Desc)
                for l=1:length(Xin(1,:))
                    if strcmp(Desc(i),Xlabels(l))
                        Xtest(:,i)=Xin(:,l);
                        break;
                    end
                end
            end
            
            if salt ==1
                Xtest=[Xtest SaltIndex];
                pred = nnrpred(Xtest,train.MP.model_s.set.train,train.MP.model_s.set.y,train.MP.model_s.set.K,train.MP.model_s.set.dist_type,train.MP.model_s.set.param.pret_type);
                AD=classical_leverage(train.MP.model_s.set.train,Xtest,'auto');
            else
                pred = nnrpred(Xtest,train.MP.model.set.train,train.MP.model.set.y,train.MP.model.set.K,train.MP.model.set.dist_type,train.MP.model.set.param.pret_type);
                AD=classical_leverage(train.MP.model.set.train,Xtest,'auto');
            end
            
            res.MoleculeID=MoleculeNames;
            
            res.MP_pred(:,1)=pred.y_pred_weighted;
            %AD=classical_leverage(train.MP.model.set.train,Xtest,'auto');
            res.AD_MP=abs(AD.inorout-1)';
            

%            res.Sim_index1=1./(1+median(pred.dc,2)); 
%             if isnan(res.Sim_index)
%                 res.Sim_index=0;
%             end

            %res.Sim_index=1./(1+nanmedian(pred.dc,2));
          
            res.Sim_index_MP=zeros(size(Xtest,1),1);
            res.Conf_index_MP=zeros(size(Xtest,1),1);
            
            MP_CAS_neighbor=cell(size(Xtest,1),5);
            MP_InChiKey_neighbor=cell(size(Xtest,1),5);
            MP_Exp_neighbor=zeros(size(Xtest,1),5);
            MP_pred_neighbor=zeros(size(Xtest,1),5);
            
            for i=1:size(Xtest(:,1))
                MP_CAS_neighbor(i,:)=train.MP.CAS(pred.neighbors(i,:));
                MP_InChiKey_neighbor(i,:)=train.MP.InChiKey(pred.neighbors(i,:));
                MP_Exp_neighbor(i,:)=train.MP.model.set.y(pred.neighbors(i,:));
                MP_pred_neighbor(i,:)=train.MP.model.yc_weighted(pred.neighbors(i,:));
                
%                 rmse=calc_reg_param(res.MP_Exp_neighbor(i,:),res.MP_pred_neighbor(i,:));
%                 res.Conf_index(i,1)=1/(1+rmse.RMSEC/50);
                
                res.Sim_index_MP(i,1)=1./(1+pred.dc(i,~isnan(pred.dc(i,:)))*pred.w(i,~isnan(pred.dc(i,:)))');
                
                if isempty(find(~isnan(pred.dc(i,:)), 1))
                    res.Sim_index_MP(i)=0;
                    res.AD_MP(i)=0;
                end
                
                res.Conf_index_MP(i,1)=1/(1+sqrt(((MP_Exp_neighbor(i,:)-MP_pred_neighbor(i,:)).^2)*pred.w(i,:)')/50);
                
                if neighbors==1
                    res.MP_CAS_neighbor(i,:)=MP_CAS_neighbor(i,:);
                    res.MP_InChiKey_neighbor(i,:)=MP_InChiKey_neighbor(i,:);
                    res.MP_Exp_neighbor(i,:)=MP_Exp_neighbor(i,:);
                    res.MP_pred_neighbor(i,:)=MP_pred_neighbor(i,:);
                end
                
                
                if strcmpi(ext,'.txt') && sep==1
                   
                    %res.Xtest=Xtest;
                    fprintf(output(j),'\t Molecule %s:\n', MoleculeNames{i});
                    fprintf(output(j),'MP predicted= %.3f\n', res.MP_pred(i));
                    if res.AD_MP(i)==1
                        fprintf(output(j),'AD: inside\n');
                    else
                        fprintf(output(j),'AD: outside\n');
                    end
                    fprintf(output(j),'Sim_index= %.2f\n', res.Sim_index_MP(i));
                    fprintf(output(j),'Conf_index= %.2f\n', res.Conf_index_MP(i));
                    %CAS=strjoin(res.MP_CAS_neighbor(i,1:5),',\t');
                    %CAS=strrep([res.CAS_neighbors(i,1:5)],' ',', ');
                    if neighbors==1
                        fprintf(output(j),'CAS of the %i nearest neighbors:%15s,%15s,%15s,%15s,%15s\n',train.MP.model.set.K, res.MP_CAS_neighbor{i,1:5});
                        fprintf(output(j),'Exp of the %i nearest neighbors:%15.3f,%15.3f,%15.3f,%15.3f,%15.3f\n',train.MP.model.set.K, res.MP_Exp_neighbor(i,1:5));
                        fprintf(output(j),'Pred of the %i nearest neighbors:%14.3f,%15.3f,%15.3f,%15.3f,%15.3f\n\n',train.MP.model.set.K, res.MP_pred_neighbor(i,1:5));
                    end
                    
                elseif strcmpi(ext,'.txt') && sep==0
                    
                    
                    %res.Xtest=Xtest;
                    fprintf(output,'\t Molecule %s:\n', MoleculeNames{i});
                    fprintf(output,'MP predicted= %.3f\n', res.MP_pred(i));
                    if res.AD_MP(i)==1
                        fprintf(output,'AD: inside\n');
                    else
                        fprintf(output,'AD: outside\n');
                    end
                    fprintf(output,'Sim_index= %.2f\n', res.Sim_index_MP(i));
                    fprintf(output,'Conf_index= %.2f\n', res.Conf_index_MP(i));
                    %CAS=strjoin(res.MP_CAS_neighbor(i,1:5),',\t');
                    %CAS=strrep([res.CAS_neighbors(i,1:5)],' ',', ');
                    if neighbors==1
                        fprintf(output,'CAS of the %i nearest neighbors:%15s,%15s,%15s,%15s,%15s\n',train.MP.model.set.K, res.MP_CAS_neighbor{i,1:5});
                        fprintf(output,'Exp of the %i nearest neighbors:%15.3f,%15.3f,%15.3f,%15.3f,%15.3f\n',train.MP.model.set.K, res.MP_Exp_neighbor(i,1:5));
                        fprintf(output,'Pred of the %i nearest neighbors:%14.3f,%15.3f,%15.3f,%15.3f,%15.3f\n\n',train.MP.model.set.K, res.MP_pred_neighbor(i,1:5));
                    end
                end
            end
            
            
            if sep==1 && strcmpi(ext,'.csv')
                T=struct2table(res);
                if printtDesc==1
                    Xtest=array2table(Xtest,'VariableNames',Desc);
                    
                    T=[T Xtest];
                end
                writetable(T,FileOut{j},'Delimiter',',');%,'QuoteStrings',true);
                fclose(output(j));
                
            elseif sep==0 && printtDesc==1 && strcmpi(ext,'.csv')
                
                
                Xtest(:,ismember(Desc,DescNames))=[];
            
                Desc(ismember(Desc,DescNames))=[];
                
                DescNames=[DescNames Desc];
                
                DescMat=[DescMat Xtest];
            end   
            
            if sep==1
              resf.MP=res;
              clear('res');
            end
          
           %Predict BP values
           case 'bp'
            
            
            Desc=train.BP.Desc;
            
            
            if verbose>0
                disp('Predicting BP values...');
                disp(['Considered descriptors for BP model: ', num2str(length(Desc))]);
                
            end
            
            if strcmpi(ext,'.txt') && sep==0
                fprintf(output,'\n\n\t\t\t\t\t Predicting BP values... \n\n			============================================================== \n\n');
            end
            
            Xtest=zeros(size(Xin,1),length(Desc));
            
            for i=1:length(Desc)
                for l=1:length(Xin(1,:))
                    if strcmp(Desc(i),Xlabels(l))
                        Xtest(:,i)=Xin(:,l);
                        break;
                    end
                end
            end
            

            pred = nnrpred(Xtest,train.BP.model.set.train,train.BP.model.set.y,train.BP.model.set.K,train.BP.model.set.dist_type,train.BP.model.set.param.pret_type);
            
            res.MoleculeID=MoleculeNames;
            
            res.BP_pred(:,1)=pred.y_pred_weighted;
            AD=classical_leverage(train.BP.model.set.train,Xtest,'auto');
            res.AD_BP=abs(AD.inorout-1)';

            
             %res.Sim_index=1./(1+nanmedian(pred.dc,2));
             
%            res.Sim_index=1./(1+median(pred.dc,2));
%             if isnan(res.Sim_index)
%                 res.Sim_index=0;
%             end
            
            res.Sim_index_BP=zeros(size(Xtest,1),1);
            res.Conf_index_BP=zeros(size(Xtest,1),1);
            
            BP_CAS_neighbor=cell(size(Xtest,1),5);
            BP_InChiKey_neighbor=cell(size(Xtest,1),5);
            BP_Exp_neighbor=zeros(size(Xtest,1),5);
            BP_pred_neighbor=zeros(size(Xtest,1),5);
            
            for i=1:size(Xtest(:,1))
                BP_CAS_neighbor(i,:)=train.BP.CAS(pred.neighbors(i,:));
                BP_InChiKey_neighbor(i,:)=train.BP.InChiKey(pred.neighbors(i,:));
                BP_Exp_neighbor(i,:)=train.BP.model.set.y(pred.neighbors(i,:));
                BP_pred_neighbor(i,:)=train.BP.model.yc_weighted(pred.neighbors(i,:));
                
%                 rmse=calc_reg_param(res.BP_Exp_neighbor(i,:),res.BP_pred_neighbor(i,:));
%                 res.Conf_index(i,1)=1/(1+rmse.RMSEC/50);

                res.Sim_index_BP(i,1)=1./(1+pred.dc(i,~isnan(pred.dc(i,:)))*pred.w(i,~isnan(pred.dc(i,:)))');
                
                if isempty(find(~isnan(pred.dc(i,:)), 1))
                    res.Sim_index_BP(i)=0;
                    res.AD_BP(i)=0;
                end
                
                res.Conf_index_BP(i,1)=1/(1+sqrt(((BP_Exp_neighbor(i,:)-BP_pred_neighbor(i,:)).^2)*pred.w(i,:)'));
               
                if neighbors==1
                    res.BP_CAS_neighbor(i,:)=BP_CAS_neighbor(i,:);
                    res.BP_InChiKey_neighbor(i,:)=BP_InChiKey_neighbor(i,:);
                    res.BP_Exp_neighbor(i,:)=BP_Exp_neighbor(i,:);
                    res.BP_pred_neighbor(i,:)=BP_pred_neighbor(i,:);
                end
                
                if strcmpi(ext,'.txt') && sep==1

                    %res.Xtest=Xtest;
                    fprintf(output(j),'\t Molecule %s:\n', MoleculeNames{i});
                    fprintf(output(j),'BP predicted= %.3f\n', res.BP_pred(i));
                    if res.AD_BP(i)==1
                        fprintf(output(j),'AD: inside\n');
                    else
                        fprintf(output(j),'AD: outside\n');
                    end
                    fprintf(output(j),'Sim_index= %.2f\n', res.Sim_index_BP(i));
                    fprintf(output(j),'Conf_index= %.2f\n', res.Conf_index_BP(i));
                    %CAS=strjoin(res.BP_CAS_neighbor(i,1:5),',\t');
                    %CAS=strrep([res.CAS_neighbors(i,1:5)],' ',', ');
                    if neighbors==1
                        fprintf(output(j),'CAS of the %i nearest neighbors:%15s,%15s,%15s,%15s,%15s\n',train.BP.model.set.K, res.BP_CAS_neighbor{i,1:5});
                        fprintf(output(j),'Exp of the %i nearest neighbors:%15.3f,%15.3f,%15.3f,%15.3f,%15.3f\n',train.BP.model.set.K, res.BP_Exp_neighbor(i,1:5));
                        fprintf(output(j),'Pred of the %i nearest neighbors:%14.3f,%15.3f,%15.3f,%15.3f,%15.3f\n\n',train.BP.model.set.K, res.BP_pred_neighbor(i,1:5));
                    end
                    
                elseif strcmpi(ext,'.txt') && sep==0                 
                    
                    %res.Xtest=Xtest;
                    fprintf(output,'\t Molecule %s:\n', MoleculeNames{i});
                    fprintf(output,'BP predicted= %.3f\n', res.BP_pred(i));
                    if res.AD_BP(i)==1
                        fprintf(output,'AD: inside\n');
                    else
                        fprintf(output,'AD: outside\n');
                    end
                    fprintf(output,'Sim_index= %.2f\n', res.Sim_index_BP(i));
                    fprintf(output,'Conf_index= %.2f\n', res.Conf_index_BP(i));
                    %CAS=strjoin(res.BP_CAS_neighbor(i,1:5),',\t');
                    %CAS=strrep([res.CAS_neighbors(i,1:5)],' ',', ');
                    if neighbors==1
                        fprintf(output,'CAS of the %i nearest neighbors:%15s,%15s,%15s,%15s,%15s\n',train.BP.model.set.K, res.BP_CAS_neighbor{i,1:5});
                        fprintf(output,'Exp of the %i nearest neighbors:%15.3f,%15.3f,%15.3f,%15.3f,%15.3f\n',train.BP.model.set.K, res.BP_Exp_neighbor(i,1:5));
                        fprintf(output,'Pred of the %i nearest neighbors:%14.3f,%15.3f,%15.3f,%15.3f,%15.3f\n\n',train.BP.model.set.K, res.BP_pred_neighbor(i,1:5));
                    end

                end
            end
            
            
            if sep==1 && strcmpi(ext,'.csv')
                T=struct2table(res);
                if printtDesc==1
                    Xtest=array2table(Xtest,'VariableNames',Desc);
                    
                    T=[T Xtest];
                end
                writetable(T,FileOut{j},'Delimiter',',');%,'QuoteStrings',true);
                fclose(output(j));
                
            elseif sep==0 && printtDesc==1 && strcmpi(ext,'.csv')
                
                
                Xtest(:,ismember(Desc,DescNames))=[];
            
                Desc(ismember(Desc,DescNames))=[];
                
                DescNames=[DescNames Desc];
                
                DescMat=[DescMat Xtest];
            end 
           
            if sep==1
              resf.BP=res;
              clear('res');
            end
          
            
           %Predict VP values
           case {'vp' ,'logvp'}
            
            
            Desc=train.VP.Desc;
            
            
            if verbose>0
                disp('Predicting VP values in Log mmHg...');
                disp(['Considered descriptors for VP model: ', num2str(length(Desc))]);
                
            end
            
            if strcmpi(ext,'.txt') && sep==0
                fprintf(output,'\n\n\t\t\t\t\t Predicting VP values in Log mmHg... \n\n			============================================================== \n\n');
            end
            
            Xtest=zeros(size(Xin,1),length(Desc));
            
            for i=1:length(Desc)
                for l=1:length(Xin(1,:))
                    if strcmp(Desc(i),Xlabels(l))
                        Xtest(:,i)=Xin(:,l);
                        break;
                    end
                end
            end
            
            pred = nnrpred(Xtest,train.VP.model.set.train,train.VP.model.set.y,train.VP.model.set.K,train.VP.model.set.dist_type,train.VP.model.set.param.pret_type);
            
            res.MoleculeID=MoleculeNames;
            
            res.LogVP_pred(:,1)=pred.y_pred_weighted;
            AD=classical_leverage(train.VP.model.set.train,Xtest,'auto');
            res.AD_VP=abs(AD.inorout-1)';
            
            
            %res.Sim_index=1./(1+nanmedian(pred.dc,2));

%             res.Sim_index=1./(1+median(pred.dc,2));
%             if isnan(res.Sim_index)
%                 res.Sim_index=0;
%             end
            
            res.Sim_index_VP=zeros(size(Xtest,1),1);
            res.Conf_index_VP=zeros(size(Xtest,1),1);
            
            LogVP_CAS_neighbor=cell(size(Xtest,1),5);
            LogVP_InChiKey_neighbor=cell(size(Xtest,1),5);
            LogVP_Exp_neighbor=zeros(size(Xtest,1),5);
            LogVP_pred_neighbor=zeros(size(Xtest,1),5);
            
            for i=1:size(Xtest(:,1))
                LogVP_CAS_neighbor(i,:)=train.VP.CAS(pred.neighbors(i,:));
                LogVP_InChiKey_neighbor(i,:)=train.VP.InChiKey(pred.neighbors(i,:));
                LogVP_Exp_neighbor(i,:)=train.VP.model.set.y(pred.neighbors(i,:));
                LogVP_pred_neighbor(i,:)=train.VP.model.yc_weighted(pred.neighbors(i,:));
                
%                 rmse=calc_reg_param(res.LogVP_Exp_neighbor(i,:),res.LogVP_pred_neighbor(i,:));
%                 res.Conf_index(i,1)=1/(1+rmse.RMSEC);

                res.Sim_index_VP(i,1)=1./(1+pred.dc(i,~isnan(pred.dc(i,:)))*pred.w(i,~isnan(pred.dc(i,:)))');
                
                if isempty(find(~isnan(pred.dc(i,:)), 1))
                    res.Sim_index_VP(i)=0;
                    res.AD_VP(i)=0;
                end
                
                res.Conf_index_VP(i,1)=1/(1+sqrt(((LogVP_Exp_neighbor(i,:)-LogVP_pred_neighbor(i,:)).^2)*pred.w(i,:)'));
                
                if neighbors==1
                    res.LogVP_CAS_neighbor(i,:)=LogVP_CAS_neighbor(i,:);
                    res.LogVP_InChiKey_neighbor(i,:)=LogVP_InChiKey_neighbor(i,:);
                    res.LogVP_Exp_neighbor(i,:)=LogVP_Exp_neighbor(i,:);
                    res.LogVP_pred_neighbor(i,:)=LogVP_pred_neighbor(i,:);
                end
                
                if strcmpi(ext,'.txt') && sep==1
                    %res.Xtest=Xtest;
                    fprintf(output(j),'\t Molecule %s:\n', MoleculeNames{i});
                    fprintf(output(j),'LogVP predicted= %.3f\n', res.LogVP_pred(i));
                    if res.AD_VP(i)==1
                        fprintf(output(j),'AD: inside\n');
                    else
                        fprintf(output(j),'AD: outside\n');
                    end
                    fprintf(output(j),'Sim_index= %.2f\n', res.Sim_index_VP(i));
                    fprintf(output(j),'Conf_index= %.2f\n', res.Conf_index_VP(i));
                    %CAS=strjoin(res.LogVP_CAS_neighbor(i,1:5),',\t');
                    %CAS=strrep([res.CAS_neighbors(i,1:5)],' ',', ');
                    if neighbors==1
                        fprintf(output(j),'CAS of the %i nearest neighbors:%15s,%15s,%15s,%15s,%15s\n',train.VP.model.set.K, res.LogVP_CAS_neighbor{i,1:5});
                        fprintf(output(j),'Exp of the %i nearest neighbors:%15.3f,%15.3f,%15.3f,%15.3f,%15.3f\n',train.VP.model.set.K, res.LogVP_Exp_neighbor(i,1:5));
                        fprintf(output(j),'Pred of the %i nearest neighbors:%14.3f,%15.3f,%15.3f,%15.3f,%15.3f\n\n',train.VP.model.set.K, res.LogVP_pred_neighbor(i,1:5));
                    end

                    
                elseif strcmpi(ext,'.txt') && sep==0
                    
                    
                    %res.Xtest=Xtest;
                    fprintf(output,'\t Molecule %s:\n', MoleculeNames{i});
                    fprintf(output,'LogVP predicted= %.3f\n', res.LogVP_pred(i));
                    if res.AD_VP(i)==1
                        fprintf(output,'AD: inside\n');
                    else
                        fprintf(output,'AD: outside\n');
                    end
                    fprintf(output,'Sim_index= %.2f\n', res.Sim_index_VP(i));
                    fprintf(output,'Conf_index= %.2f\n', res.Conf_index_VP(i));
                    %CAS=strjoin(res.LogVP_CAS_neighbor(i,1:5),',\t');
                    %CAS=strrep([res.CAS_neighbors(i,1:5)],' ',', ');
                    if neighbors==1
                        fprintf(output,'CAS of the %i nearest neighbors:%15s,%15s,%15s,%15s,%15s\n',train.VP.model.set.K, res.LogVP_CAS_neighbor{i,1:5});
                        fprintf(output,'Exp of the %i nearest neighbors:%15.3f,%15.3f,%15.3f,%15.3f,%15.3f\n',train.VP.model.set.K, res.LogVP_Exp_neighbor(i,1:5));
                        fprintf(output,'Pred of the %i nearest neighbors:%14.3f,%15.3f,%15.3f,%15.3f,%15.3f\n\n',train.VP.model.set.K, res.LogVP_pred_neighbor(i,1:5));
                    end

                end
            end
            
            
            if sep==1 && strcmpi(ext,'.csv')
                T=struct2table(res);
                if printtDesc==1
                    Xtest=array2table(Xtest,'VariableNames',Desc);
                    
                    T=[T Xtest];
                end
                writetable(T,FileOut{j},'Delimiter',',');%,'QuoteStrings',true);
                fclose(output(j));
                
            elseif sep==0 && printtDesc==1 && strcmpi(ext,'.csv')
                
                
                Xtest(:,ismember(Desc,DescNames))=[];
            
                Desc(ismember(Desc,DescNames))=[];
                
                DescNames=[DescNames Desc];
                
                DescMat=[DescMat Xtest];
            end 
            
           if sep==1
              resf.VP=res;
              clear('res');
           end
          
            
           %Predict BCF values
           case {'bcf', 'logbcf'}
            
            
            Desc=train.BCF.Desc;
            
            
            if verbose>0
                disp('Predicting LogBCF values...');
                disp(['Considered descriptors for LogBCF model: ', num2str(length(Desc))]);
                
            end
            
            if strcmpi(ext,'.txt') && sep==0
                fprintf(output,'\n\n\t\t\t\t\t Predicting LogBCF values... \n\n			============================================================== \n\n');
            end
            
            Xtest=zeros(size(Xin,1),length(Desc));
            
            for i=1:length(Desc)
                for l=1:length(Xin(1,:))
                    if strcmp(Desc(i),Xlabels(l))
                        Xtest(:,i)=Xin(:,l);
                        break;
                    end
                end
            end
            
            pred = nnrpred(Xtest,train.BCF.model.set.train,train.BCF.model.set.y,train.BCF.model.set.K,train.BCF.model.set.dist_type,train.BCF.model.set.param.pret_type);
            
            res.MoleculeID=MoleculeNames;
            
            res.LogBCF_pred(:,1)=pred.y_pred_weighted;
            AD=classical_leverage(train.BCF.model.set.train,Xtest,'auto');
            res.AD_BCF=abs(AD.inorout-1)';
            
            
             %res.Sim_index=1./(1+nanmedian(pred.dc,2));


%             res.Sim_index=1./(1+median(pred.dc,2));
%             if isnan(res.Sim_index)
%                 res.Sim_index=0;
%             end
            
            res.Sim_index_BCF=zeros(size(Xtest,1),1);
            res.Conf_index_BCF=zeros(size(Xtest,1),1);
            
            LogBCF_CAS_neighbor=cell(size(Xtest,1),5);
            LogBCF_InChiKey_neighbor=cell(size(Xtest,1),5);
            LogBCF_Exp_neighbor=zeros(size(Xtest,1),5);
            LogBCF_pred_neighbor=zeros(size(Xtest,1),5);
            
            for i=1:size(Xtest(:,1))
                LogBCF_CAS_neighbor(i,:)=train.BCF.CAS(pred.neighbors(i,:));
                LogBCF_InChiKey_neighbor(i,:)=train.BCF.InChiKey(pred.neighbors(i,:));
                LogBCF_Exp_neighbor(i,:)=train.BCF.model.set.y(pred.neighbors(i,:));
                LogBCF_pred_neighbor(i,:)=train.BCF.model.yc_weighted(pred.neighbors(i,:));
                
%                 rmse=calc_reg_param(res.LogBCF_Exp_neighbor(i,:),res.LogBCF_pred_neighbor(i,:));
%                 res.Conf_index(i,1)=1/(1+rmse.RMSEC);
                %res.Conf_index2(i,1)=(res.Conf_index(i)*res.Sim_index(i))^0.5;
                
                res.Sim_index_BCF(i,1)=1./(1+pred.dc(i,~isnan(pred.dc(i,:)))*pred.w(i,~isnan(pred.dc(i,:)))');
                
                if isnan(res.Sim_index_BCF(i))
                    res.Sim_index_BCF(i)=0;
                    res.AD_BCF(i)=0;
                end
                
                res.Conf_index_BCF(i,1)=1/(1+sqrt(((LogBCF_Exp_neighbor(i,:)-LogBCF_pred_neighbor(i,:)).^2)*pred.w(i,:)'));
                
               if neighbors==1
                   res.LogBCF_CAS_neighbor(i,:)=LogBCF_CAS_neighbor(i,:);
                   res.LogBCF_InChiKey_neighbor(i,:)=LogBCF_InChiKey_neighbor(i,:);
                   res.LogBCF_Exp_neighbor(i,:)=LogBCF_Exp_neighbor(i,:);
                   res.LogBCF_pred_neighbor(i,:)=LogBCF_pred_neighbor(i,:);
               end
                   
                
                
                if strcmpi(ext,'.txt') && sep==1

                    %res.Xtest=Xtest;
                    fprintf(output(j),'\t Molecule %s:\n', MoleculeNames{i});
                    fprintf(output(j),'LogBCF predicted= %.3f\n', res.LogBCF_pred(i));
                    if res.AD_BCF(i)==1
                        fprintf(output(j),'AD: inside\n');
                    else
                        fprintf(output(j),'AD: outside\n');
                    end
                    fprintf(output(j),'Sim_index= %.2f\n', res.Sim_index_BCF(i));
                    fprintf(output(j),'Conf_index= %.2f\n', res.Conf_index_BCF(i));
                    %CAS=strjoin(res.LogBCF_CAS_neighbor(i,1:5),',\t');
                    %CAS=strrep([res.CAS_neighbors(i,1:5)],' ',', ');
                    if neighbors==1
                        fprintf(output(j),'CAS of the %i nearest neighbors:%15s,%15s,%15s,%15s,%15s\n',train.BCF.model.set.K, res.LogBCF_CAS_neighbor{i,1:5});
                        fprintf(output(j),'Exp of the %i nearest neighbors:%15.3f,%15.3f,%15.3f,%15.3f,%15.3f\n',train.BCF.model.set.K, res.LogBCF_Exp_neighbor(i,1:5));
                        fprintf(output(j),'Pred of the %i nearest neighbors:%14.3f,%15.3f,%15.3f,%15.3f,%15.3f\n\n',train.BCF.model.set.K, res.LogBCF_pred_neighbor(i,1:5));
                    end

                    
                elseif strcmpi(ext,'.txt') && sep==0
                    
                    
                    %res.Xtest=Xtest;
                    fprintf(output,'\t Molecule %s:\n', MoleculeNames{i});
                    fprintf(output,'LogBCF predicted= %.3f\n', res.LogBCF_pred(i));
                    if res.AD_BCF(i)==1
                        fprintf(output,'AD: inside\n');
                    else
                        fprintf(output,'AD: outside\n');
                    end
                    fprintf(output,'Sim_index= %.2f\n', res.Sim_index_BCF(i));
                    fprintf(output,'Conf_index= %.2f\n', res.Conf_index_BCF(i));
                    %CAS=strjoin(res.LogBCF_CAS_neighbor(i,1:5),',\t');
                    %CAS=strrep([res.CAS_neighbors(i,1:5)],' ',', ');
                    if neighbors==1
                        fprintf(output,'CAS of the %i nearest neighbors:%15s,%15s,%15s,%15s,%15s\n',train.BCF.model.set.K, res.LogBCF_CAS_neighbor{i,1:5});
                        fprintf(output,'Exp of the %i nearest neighbors:%15.3f,%15.3f,%15.3f,%15.3f,%15.3f\n',train.BCF.model.set.K, res.LogBCF_Exp_neighbor(i,1:5));
                        fprintf(output,'Pred of the %i nearest neighbors:%14.3f,%15.3f,%15.3f,%15.3f,%15.3f\n\n',train.BCF.model.set.K, res.LogBCF_pred_neighbor(i,1:5));
                    end

                end
            end
            
                       
            
            if sep==1 && strcmpi(ext,'.csv')
                T=struct2table(res);
                if printtDesc==1
                    Xtest=array2table(Xtest,'VariableNames',Desc);
                    
                    T=[T Xtest];
                end
                writetable(T,FileOut{j},'Delimiter',',');%,'QuoteStrings',true);
                fclose(output(j));
                
            elseif sep==0 && printtDesc==1 && strcmpi(ext,'.csv')
                
                
                Xtest(:,ismember(Desc,DescNames))=[];
            
                Desc(ismember(Desc,DescNames))=[];
                
                DescNames=[DescNames Desc];
                
                DescMat=[DescMat Xtest];
            end 
           
            if sep==1
              resf.BCF=res;
              clear('res');
            end
          
           %Predict WS values
           case {'ws','logws'}
            
            
            Desc=train.WS.Desc;
            
            
            if verbose>0
                disp('Predicting LogWS values...');
                disp(['Considered descriptors for WS model: ', num2str(length(Desc))]);
                
            end
            if strcmpi(ext,'.txt') && sep==0
                fprintf(output,'\n\n\t\t\t\t\t Predicting LogWS values... \n\n			============================================================== \n\n');
            end
            
            Xtest=zeros(size(Xin,1),length(Desc));
            
            for i=1:length(Desc)
                for l=1:length(Xin(1,:))
                    if strcmp(Desc(i),Xlabels(l))
                        Xtest(:,i)=Xin(:,l);
                        break;
                    end
                end
            end
            
            pred = nnrpred(Xtest,train.WS.model.set.train,train.WS.model.set.y,train.WS.model.set.K,train.WS.model.set.dist_type,train.WS.model.set.param.pret_type);
            
            res.MoleculeID=MoleculeNames;
            
            res.LogWS_pred(:,1)=pred.y_pred_weighted;
            AD=classical_leverage(train.WS.model.set.train,Xtest,'auto');
            res.AD_WS=abs(AD.inorout-1)';
            
            
             %res.Sim_index=1./(1+nanmedian(pred.dc,2));

%             res.Sim_index=1./(1+median(pred.dc,2));
%             if isnan(res.Sim_index)
%                 res.Sim_index=0;
%             end
            
            res.Sim_index_WS=zeros(size(Xtest,1),1);
            res.Conf_index_WS=zeros(size(Xtest,1),1);
            
            LogWS_CAS_neighbor=cell(size(Xtest,1),5);
            LogWS_InChiKey_neighbor=cell(size(Xtest,1),5);
            LogWS_Exp_neighbor=zeros(size(Xtest,1),5);
            LogWS_pred_neighbor=zeros(size(Xtest,1),5);
            
            for i=1:size(Xtest(:,1))
                LogWS_CAS_neighbor(i,:)=train.WS.CAS(pred.neighbors(i,:));
                LogWS_InChiKey_neighbor(i,:)=train.WS.InChiKey(pred.neighbors(i,:));
                LogWS_Exp_neighbor(i,:)=train.WS.model.set.y(pred.neighbors(i,:));
                LogWS_pred_neighbor(i,:)=train.WS.model.yc_weighted(pred.neighbors(i,:));
                
%                 rmse=calc_reg_param(res.LogWS_Exp_neighbor(i,:),res.LogWS_pred_neighbor(i,:));
%                 res.Conf_index(i,1)=1/(1+rmse.RMSEC);
                
                res.Sim_index_WS(i,1)=1./(1+pred.dc(i,~isnan(pred.dc(i,:)))*pred.w(i,~isnan(pred.dc(i,:)))');
                
                if isempty(find(~isnan(pred.dc(i,:)), 1))
                    res.Sim_index_WS(i)=0;
                    res.AD_WS(i)=0;
                end
                
                res.Conf_index_WS(i,1)=1/(1+sqrt(((LogWS_Exp_neighbor(i,:)-LogWS_pred_neighbor(i,:)).^2)*pred.w(i,:)'));
                
                if neighbors==1
                    res.LogWS_CAS_neighbor(i,:)=LogWS_CAS_neighbor(i,:);
                    res.LogWS_InChiKey_neighbor(i,:)=LogWS_InChiKey_neighbor(i,:);
                    res.LogWS_Exp_neighbor(i,:)=LogWS_Exp_neighbor(i,:);
                    res.LogWS_pred_neighbor(i,:)=LogWS_pred_neighbor(i,:);
                end
                
                if strcmpi(ext,'.txt') && sep==1
                    
                    %res.Xtest=Xtest;
                    fprintf(output(j),'\t Molecule %s:\n', MoleculeNames{i});
                    fprintf(output(j),'LogWS predicted= %.3f\n', res.LogWS_pred(i));
                    if res.AD_WS(i)==1
                        fprintf(output(j),'AD: inside\n');
                    else
                        fprintf(output(j),'AD: outside\n');
                    end
                    fprintf(output(j),'Sim_index= %.2f\n', res.Sim_index_WS(i));
                    fprintf(output(j),'Conf_index= %.2f\n', res.Conf_index_WS(i));
                    %CAS=strjoin(res.LogWS_CAS_neighbor(i,1:5),',\t');
                    %CAS=strrep([res.CAS_neighbors(i,1:5)],' ',', ');
                    if neighbors==1
                        fprintf(output(j),'CAS of the %i nearest neighbors:%15s,%15s,%15s,%15s,%15s\n',train.WS.model.set.K, res.LogWS_CAS_neighbor{i,1:5});
                        fprintf(output(j),'Exp of the %i nearest neighbors:%15.3f,%15.3f,%15.3f,%15.3f,%15.3f\n',train.WS.model.set.K, res.LogWS_Exp_neighbor(i,1:5));
                        fprintf(output(j),'Pred of the %i nearest neighbors:%14.3f,%15.3f,%15.3f,%15.3f,%15.3f\n\n',train.WS.model.set.K, res.LogWS_pred_neighbor(i,1:5));
                    end

                    
                elseif strcmpi(ext,'.txt') && sep==0

                    %res.Xtest=Xtest;
                    fprintf(output,'\t Molecule %s:\n', MoleculeNames{i});
                    fprintf(output,'LogWS predicted= %.3f\n', res.LogWS_pred(i));
                    if res.AD_WS(i)==1
                        fprintf(output,'AD: inside\n');
                    else
                        fprintf(output,'AD: outside\n');
                    end
                    fprintf(output,'Sim_index= %.2f\n', res.Sim_index_WS(i));
                    fprintf(output,'Conf_index= %.2f\n', res.Conf_index_WS(i));
                    %CAS=strjoin(res.LogWS_CAS_neighbor(i,1:5),',\t');
                    %CAS=strrep([res.CAS_neighbors(i,1:5)],' ',', ');
                    if neighbors==1
                        fprintf(output,'CAS of the %i nearest neighbors:%15s,%15s,%15s,%15s,%15s\n',train.WS.model.set.K, res.LogWS_CAS_neighbor{i,1:5});
                        fprintf(output,'Exp of the %i nearest neighbors:%15.3f,%15.3f,%15.3f,%15.3f,%15.3f\n',train.WS.model.set.K, res.LogWS_Exp_neighbor(i,1:5));
                        fprintf(output,'Pred of the %i nearest neighbors:%14.3f,%15.3f,%15.3f,%15.3f,%15.3f\n\n',train.WS.model.set.K, res.LogWS_pred_neighbor(i,1:5));
                    end

                end
            end
            
            
            if sep==1 && strcmpi(ext,'.csv')
                T=struct2table(res);
                if printtDesc==1
                    Xtest=array2table(Xtest,'VariableNames',Desc);
                    
                    T=[T Xtest];
                end
                writetable(T,FileOut{j},'Delimiter',',');%,'QuoteStrings',true);
                fclose(output(j));
                
            elseif sep==0 && printtDesc==1 && strcmpi(ext,'.csv')
                
                
                Xtest(:,ismember(Desc,DescNames))=[];
            
                Desc(ismember(Desc,DescNames))=[];
                
                DescNames=[DescNames Desc];
                
                DescMat=[DescMat Xtest];
            end 
            
            if sep==1
              resf.WS=res;
              clear('res');
            end
          
            
            
            %Predict AOP values
           case {'aop','logoh','aoh'}
            
            
            Desc=train.AOP.Desc;
            
            
            if verbose>0
                disp('Predicting LogOH values...');
                disp(['Considered descriptors for AOH model: ', num2str(length(Desc))]);
                
            end
            
            if strcmpi(ext,'.txt') && sep==0
                fprintf(output,'\n\n\t\t\t\t\t Predicting LogOH values... \n\n			============================================================== \n\n');
            end
            
            Xtest=zeros(size(Xin,1),length(Desc));
            
            for i=1:length(Desc)
                for l=1:length(Xin(1,:))
                    if strcmp(Desc(i),Xlabels(l))
                        Xtest(:,i)=Xin(:,l);
                        break;
                    end
                end
            end
            
            pred = nnrpred(Xtest,train.AOP.model.set.train,train.AOP.model.set.y,train.AOP.model.set.K,train.AOP.model.set.dist_type,train.AOP.model.set.param.pret_type);
            
            res.MoleculeID=MoleculeNames;
            
            res.LogOH_pred(:,1)=pred.y_pred_weighted;
            AD=classical_leverage(train.AOP.model.set.train,Xtest,'auto');
            res.AD_AOP=abs(AD.inorout-1)';
            
            
             %res.Sim_index=1./(1+nanmedian(pred.dc,2));


%             res.Sim_index=1./(1+median(pred.dc,2));
%             if isnan(res.Sim_index)
%                 res.Sim_index=0;
%             end
            
            res.Sim_index_AOP=zeros(size(Xtest,1),1);
            res.Conf_index_AOP=zeros(size(Xtest,1),1);
            
            AOH_CAS_neighbor=cell(size(Xtest,1),5);
            AOH_InChiKey_neighbor=cell(size(Xtest,1),5);
            LogOH_Exp_neighbor=zeros(size(Xtest,1),5);
            LogOH_pred_neighbor=zeros(size(Xtest,1),5);
            
            for i=1:size(Xtest(:,1))
                AOH_CAS_neighbor(i,:)=train.AOP.CAS(pred.neighbors(i,:));
                AOH_InChiKey_neighbor(i,:)=train.AOP.InChiKey(pred.neighbors(i,:));
                LogOH_Exp_neighbor(i,:)=train.AOP.model.set.y(pred.neighbors(i,:));
                LogOH_pred_neighbor(i,:)=train.AOP.model.yc_weighted(pred.neighbors(i,:));
                
%                 rmse=calc_reg_param(res.LogOH_Exp_neighbor(i,:),res.LogOH_pred_neighbor(i,:));
%                 res.Conf_index(i,1)=1/(1+rmse.RMSEC);

                res.Sim_index_AOP(i,1)=1./(1+pred.dc(i,~isnan(pred.dc(i,:)))*pred.w(i,~isnan(pred.dc(i,:)))');
                
                if isempty(find(~isnan(pred.dc(i,:)), 1))
                    res.Sim_index_AOP(i)=0;
                    res.AD_AOP(i)=0;
                end
                
                res.Conf_index_AOP(i,1)=1/(1+sqrt(((LogOH_Exp_neighbor(i,:)-LogOH_pred_neighbor(i,:)).^2)*pred.w(i,:)'));
                
                if neighbors==1
                    res.AOH_CAS_neighbor(i,:)=AOH_CAS_neighbor(i,:);
                    res.AOH_InChiKey_neighbor(i,:)=AOH_InChiKey_neighbor(i,:);
                    res.LogOH_Exp_neighbor(i,:)=LogOH_Exp_neighbor(i,:);
                    res.LogOH_pred_neighbor(i,:)=LogOH_pred_neighbor(i,:);
                end
                
                if strcmpi(ext,'.txt') && sep==1
  
                    %res.Xtest=Xtest;
                    fprintf(output(j),'\t Molecule %s:\n', MoleculeNames{i});
                    fprintf(output(j),'LogOH predicted= %.3f\n', res.LogOH_pred(i));
                    if res.AD_AOP(i)==1
                        fprintf(output(j),'AD: inside\n');
                    else
                        fprintf(output(j),'AD: outside\n');
                    end
                    fprintf(output(j),'Sim_index= %.2f\n', res.Sim_index_AOP(i));
                    fprintf(output(j),'Conf_index= %.2f\n', res.Conf_index_AOP(i));
                    %CAS=strjoin(res.AOH_CAS_neighbor(i,1:5),',\t');
                    %CAS=strrep([res.CAS_neighbors(i,1:5)],' ',', ');
                    if neighbors==1
                        fprintf(output(j),'CAS of the %i nearest neighbors:%15s,%15s,%15s,%15s,%15s\n',train.AOP.model.set.K, res.AOH_CAS_neighbor{i,1:5});
                        fprintf(output(j),'Exp of the %i nearest neighbors:%15.3f,%15.3f,%15.3f,%15.3f,%15.3f\n',train.AOP.model.set.K, res.LogOH_Exp_neighbor(i,1:5));
                        fprintf(output(j),'Pred of the %i nearest neighbors:%14.3f,%15.3f,%15.3f,%15.3f,%15.3f\n\n',train.AOP.model.set.K, res.LogOH_pred_neighbor(i,1:5));
                    end

                    
                elseif strcmpi(ext,'.txt') && sep==0
                    
                    
                    %res.Xtest=Xtest;
                    fprintf(output,'\t Molecule %s:\n', MoleculeNames{i});
                    fprintf(output,'LogOH predicted= %.3f\n', res.LogOH_pred(i));
                    if res.AD_AOP(i)==1
                        fprintf(output,'AD: inside\n');
                    else
                        fprintf(output,'AD: outside\n');
                    end
                    fprintf(output,'Sim_index= %.2f\n', res.Sim_index_AOP(i));
                    fprintf(output,'Conf_index= %.2f\n', res.Conf_index_AOP(i));
                    %CAS=strjoin(res.AOH_CAS_neighbor(i,1:5),',\t');
                    %CAS=strrep([res.CAS_neighbors(i,1:5)],' ',', ');
                    if neighbors==1
                        fprintf(output,'CAS of the %i nearest neighbors:%15s,%15s,%15s,%15s,%15s\n',train.AOP.model.set.K, res.AOH_CAS_neighbor{i,1:5});
                        fprintf(output,'Exp of the %i nearest neighbors:%15.3f,%15.3f,%15.3f,%15.3f,%15.3f\n',train.AOP.model.set.K, res.LogOH_Exp_neighbor(i,1:5));
                        fprintf(output,'Pred of the %i nearest neighbors:%14.3f,%15.3f,%15.3f,%15.3f,%15.3f\n\n',train.AOP.model.set.K, res.LogOH_pred_neighbor(i,1:5));
                    end

                end
            end
            
            
            if sep==1 && strcmpi(ext,'.csv')
                T=struct2table(res);
                if printtDesc==1
                    Xtest=array2table(Xtest,'VariableNames',Desc);
                    
                    T=[T Xtest];
                end
                writetable(T,FileOut{j},'Delimiter',',');%,'QuoteStrings',true);
                fclose(output(j));
                
            elseif sep==0 && printtDesc==1 && strcmpi(ext,'.csv')
                
                
                Xtest(:,ismember(Desc,DescNames))=[];
            
                Desc(ismember(Desc,DescNames))=[];
                
                DescNames=[DescNames Desc];
                
                DescMat=[DescMat Xtest];
            end
            
            if sep==1
              resf.AOH=res;
              clear('res');
            end
          
               
            %Predict BioHC values
            case {'biohc','loghl','biodeg'}
            
            
            Desc=train.BioHC.Desc;
            
            
            if verbose>0
                disp('Predicting LogHalfLife values...');
                disp(['Considered descriptors for BioDegHL model: ', num2str(length(Desc))]);
                
            end
            if strcmpi(ext,'.txt') && sep==0
                fprintf(output,'\n\n\t\t\t\t\t Predicting Biodegradability in LogHalfLife... \n\n			============================================================== \n\n');
            end
            
            Xtest=zeros(size(Xin,1),length(Desc));
            
            for i=1:length(Desc)
                for l=1:length(Xin(1,:))
                    if strcmp(Desc(i),Xlabels(l))
                        Xtest(:,i)=Xin(:,l);
                        break;
                    end
                end
            end
            
            pred = nnrpred(Xtest,train.BioHC.model.set.train,train.BioHC.model.set.y,train.BioHC.model.set.K,train.BioHC.model.set.dist_type,train.BioHC.model.set.param.pret_type);
            
            res.MoleculeID=MoleculeNames;
            
            res.BioDeg_LogHalfLife_pred(:,1)=pred.y_pred_weighted;
            AD=classical_leverage(train.BioHC.model.set.train,Xtest,'auto');
            res.AD_BioDeg=abs(AD.inorout-1)';
            
            
%             res.dc=pred.dc;
             %res.Sim_index1=1./(1+nanmedian(pred.dc,2));

%             res.Sim_index=1./(1+median(pred.dc,2));
%             if isnan(res.Sim_index1)
%                 res.Sim_index1=0;
%             end
            
            res.Sim_index_BioDeg=zeros(size(Xtest,1),1);
            res.Conf_index_BioDeg=zeros(size(Xtest,1),1);
            
            BioDeg_CAS_neighbor=cell(size(Xtest,1),5);
            BioDeg_InChiKey_neighbor=cell(size(Xtest,1),5);
            BioDeg_LogHalfLife_Exp_neighbor=zeros(size(Xtest,1),5);
            BioDeg_LogHalfLife_pred_neighbor=zeros(size(Xtest,1),5);
            
            for i=1:size(Xtest(:,1))
                BioDeg_CAS_neighbor(i,:)=train.BioHC.CAS(pred.neighbors(i,:));
                BioDeg_InChiKey_neighbor(i,:)=train.BioHC.InChiKey(pred.neighbors(i,:));
                BioDeg_LogHalfLife_Exp_neighbor(i,:)=train.BioHC.model.set.y(pred.neighbors(i,:));
                BioDeg_LogHalfLife_pred_neighbor(i,:)=train.BioHC.model.yc_weighted(pred.neighbors(i,:));
                
%                 rmse=calc_reg_param(res.BioDeg_LogHalfLife_Exp_neighbor(i,:),res.BioDeg_LogHalfLife_pred_neighbor(i,:));
%                 res.Conf_index(i,1)=1/(1+rmse.RMSEC);

                res.Sim_index_BioDeg(i,1)=1./(1+pred.dc(i,~isnan(pred.dc(i,:)))*pred.w(i,~isnan(pred.dc(i,:)))');
                
                if isempty(find(~isnan(pred.dc(i,:)), 1))
                    res.Sim_index_BioDeg(i)=0;
                    res.AD_BioDeg(i)=0;
                end
                
                res.Conf_index_BioDeg(i,1)=1/(1+sqrt(((BioDeg_LogHalfLife_Exp_neighbor(i,:)-BioDeg_LogHalfLife_pred_neighbor(i,:)).^2)*pred.w(i,:)'));
                
                if neighbors==1
                    res.BioDeg_CAS_neighbor(i,:)=BioDeg_CAS_neighbor(i,:);
                    res.BioDeg_InChiKey_neighbor(i,:)=BioDeg_InChiKey_neighbor(i,:);
                    res.BioDeg_LogHalfLife_Exp_neighbor(i,:)=BioDeg_LogHalfLife_Exp_neighbor(i,:);
                    res.BioDeg_LogHalfLife_pred_neighbor(i,:)=BioDeg_LogHalfLife_pred_neighbor(i,:);
                end
                
                if strcmpi(ext,'.txt') && sep==1
                    %res.Xtest=Xtest;
                    fprintf(output(j),'\t Molecule %s:\n', MoleculeNames{i});
                    fprintf(output(j),'BioDeg_LogHalfLife predicted= %.3f\n', res.BioDeg_LogHalfLife_pred(i));
                    if res.AD_BioDeg(i)==1
                        fprintf(output(j),'AD: inside\n');
                    else
                        fprintf(output(j),'AD: outside\n');
                    end
                    fprintf(output(j),'Sim_index= %.2f\n', res.Sim_index_BioDeg(i));
                    fprintf(output(j),'Conf_index= %.2f\n', res.Conf_index_BioDeg(i));
                    %CAS=strjoin(res.BioDeg_CAS_neighbor(i,1:5),',\t');
                    %CAS=strrep([res.CAS_neighbors(i,1:5)],' ',', ');
                    if neighbors==1
                        fprintf(output(j),'CAS of the %i nearest neighbors:%15s,%15s,%15s,%15s,%15s\n',train.BioHC.model.set.K, res.BioDeg_CAS_neighbor{i,1:5});
                        fprintf(output(j),'Exp of the %i nearest neighbors:%15.3f,%15.3f,%15.3f,%15.3f,%15.3f\n',train.BioHC.model.set.K, res.BioDeg_LogHalfLife_Exp_neighbor(i,1:5));
                        fprintf(output(j),'Pred of the %i nearest neighbors:%14.3f,%15.3f,%15.3f,%15.3f,%15.3f\n\n',train.BioHC.model.set.K, res.BioDeg_LogHalfLife_pred_neighbor(i,1:5));
                    end

                    
                elseif strcmpi(ext,'.txt') && sep==0
                    
                    
                    %res.Xtest=Xtest;
                    fprintf(output,'\t Molecule %s:\n', MoleculeNames{i});
                    fprintf(output,'BioDeg_LogHalfLife predicted= %.3f\n', res.BioDeg_LogHalfLife_pred(i));
                    if res.AD_BioDeg(i)==1
                        fprintf(output,'AD: inside\n');
                    else
                        fprintf(output,'AD: outside\n');
                    end
                    fprintf(output,'Sim_index= %.2f\n', res.Sim_index_BioDeg(i));
                    fprintf(output,'Conf_index= %.2f\n', res.Conf_index_BioDeg(i));
                    %CAS=strjoin(res.BioDeg_CAS_neighbor(i,1:5),',\t');
                    %CAS=strrep([res.CAS_neighbors(i,1:5)],' ',', ');
                    if neighbors==1
                        fprintf(output,'CAS of the %i nearest neighbors:%15s,%15s,%15s,%15s,%15s\n',train.BioHC.model.set.K, res.BioDeg_CAS_neighbor{i,1:5});
                        fprintf(output,'Exp of the %i nearest neighbors:%15.3f,%15.3f,%15.3f,%15.3f,%15.3f\n',train.BioHC.model.set.K, res.BioDeg_LogHalfLife_Exp_neighbor(i,1:5));
                        fprintf(output,'Pred of the %i nearest neighbors:%14.3f,%15.3f,%15.3f,%15.3f,%15.3f\n\n',train.BioHC.model.set.K, res.BioDeg_LogHalfLife_pred_neighbor(i,1:5));
                    end

                end
            end
            
            
            if sep==1 && strcmpi(ext,'.csv')
                T=struct2table(res);
                if printtDesc==1
                    Xtest=array2table(Xtest,'VariableNames',Desc);
                    
                    T=[T Xtest];
                end
                writetable(T,FileOut{j},'Delimiter',',');%,'QuoteStrings',true);
                fclose(output(j));
                
            elseif sep==0 && printtDesc==1 && strcmpi(ext,'.csv')
                
                
                Xtest(:,ismember(Desc,DescNames))=[];
            
                Desc(ismember(Desc,DescNames))=[];
                
                DescNames=[DescNames Desc];
                
                DescMat=[DescMat Xtest];
            end
            
            if sep==1
              resf.BioDeg=res;
              clear('res');
            end
          
            %Predict Biowin values
            case {'biowin','rb','readybiodeg'}
            
            
            Desc=train.Biowin.Desc;
            
            
            if verbose>0
                disp('Predicting Ready Biodegradability...');
                disp(['Considered descriptors for ReadyBiodeg model: ', num2str(length(Desc))]);
                
            end
            
            if strcmpi(ext,'.txt') && sep==0
                fprintf(output,'\n\n\t\t\t\t\t Predicting Ready Biodegradability... \n\n			============================================================== \n\n');
            end
            
            Xtest=zeros(size(Xin,1),length(Desc));
            
            for i=1:length(Desc)
                for l=1:length(Xin(1,:))
                    if strcmp(Desc(i),Xlabels(l))
                        Xtest(:,i)=Xin(:,l);
                        break;
                    end
                end
            end
            
            pred = knnpred(Xtest,train.Biowin.model.set.train,train.Biowin.model.set.class,train.Biowin.model.set.K,train.Biowin.model.set.dist_type,train.Biowin.model.set.param.pret_type);
            
            %pred.w = (ones(1,train.Biowin.model.set.K)./train.Biowin.model.set.K)';
            
            res.MoleculeID=MoleculeNames;
            
            res.ReadyBiodeg_pred(:,1)=pred.class_pred-1;
            AD=classical_leverage(train.Biowin.model.set.train,Xtest,'auto');
            res.AD_ReadyBiodeg=abs(AD.inorout-1)';
            %
            
            
            %res.dc=pred.dc;
            res.Sim_index_ReadyBiodeg=1./(1+nanmedian(pred.dc,2));
            res.Sim_index_ReadyBiodeg(isnan(res.Sim_index_ReadyBiodeg))=0;
            
%             res.Sim_index=1./(1+median(pred.dc,2));
%             if isnan(res.Sim_index)
%                 res.Sim_index=0;
%             end
            
            
            
%             res.Sim_index=zeros(size(Xtest,1),1);
%             res.Conf_index1=zeros(size(Xtest,1),1);
            res.Conf_index_ReadyBiodeg=zeros(size(Xtest,1),1);
            
            ReadyBiodeg_CAS_neighbor=cell(size(Xtest,1),5);
            ReadyBiodeg_InChiKey_neighbor=cell(size(Xtest,1),5);
            ReadyBiodeg_Exp_neighbor=zeros(size(Xtest,1),5);
            ReadyBiodeg_pred_neighbor=zeros(size(Xtest,1),5);
            
            
            for i=1:size(Xtest(:,1))
                ReadyBiodeg_CAS_neighbor(i,:)=train.Biowin.CAS(pred.neighbors(i,:));
                ReadyBiodeg_InChiKey_neighbor(i,:)=train.Biowin.InChiKey(pred.neighbors(i,:));
                ReadyBiodeg_Exp_neighbor(i,:)=train.Biowin.model.set.class(pred.neighbors(i,:))-1;
                ReadyBiodeg_pred_neighbor(i,:)=train.Biowin.model.class_calc(pred.neighbors(i,:))-1;
                
                rmse=calc_reg_param(ReadyBiodeg_Exp_neighbor(i,:),ReadyBiodeg_pred_neighbor(i,:));
                res.Conf_index_ReadyBiodeg(i,1)=1/(1+rmse.RMSEC);

%                 res.Sim_index(i,1)=1./(1+pred.dc(i,~isnan(pred.dc(i,:)))*pred.w(i,~isnan(pred.dc(i,:)))');
%                 
%                 if isnan(res.Sim_index(i))
%                     res.Sim_index(i)=0;
%                 end

                
%                res.Conf_index(i,1)=1/(1+sqrt(((res.ReadyBiodeg_Exp_neighbor(i,:)-res.ReadyBiodeg_pred_neighbor(i,:)).^2)*pred.w(i,:)'));
                if neighbors==1
                    res.ReadyBiodeg_CAS_neighbor(i,:)=ReadyBiodeg_CAS_neighbor(i,:);
                    res.ReadyBiodeg_InChiKey_neighbor(i,:)=ReadyBiodeg_InChiKey_neighbor(i,:);
                    res.ReadyBiodeg_Exp_neighbor(i,:)=ReadyBiodeg_Exp_neighbor(i,:);
                    res.ReadyBiodeg_pred_neighbor(i,:)=ReadyBiodeg_pred_neighbor(i,:);
                end

                if strcmpi(ext,'.txt') && sep==1
                    
                    %res.Xtest=Xtest;
                    fprintf(output(j),'\t Molecule %s:\n', MoleculeNames{i});
                    fprintf(output(j),'ReadyBiodeg predicted= %d\n', res.ReadyBiodeg_pred(i));
                    if res.AD_ReadyBiodeg(i)==1
                        fprintf(output(j),'AD: inside\n');
                    else
                        fprintf(output(j),'AD: outside\n');
                    end
                    fprintf(output(j),'Sim_index= %.2f\n', res.Sim_index_ReadyBiodeg(i));
                    fprintf(output(j),'Conf_index= %.2f\n', res.Conf_index_ReadyBiodeg(i));
                    %CAS=strjoin(res.ReadyBiodeg_CAS_neighbor(i,1:5),',\t');
                    %CAS=strrep([res.CAS_neighbors(i,1:5)],' ',', ');
                    if neighbors==1
                        fprintf(output(j),'CAS of the %i nearest neighbors:%15s,%15s,%15s,%15s,%15s\n',train.Biowin.model.set.K, res.ReadyBiodeg_CAS_neighbor{i,1:5});
                        fprintf(output(j),'Exp of the %i nearest neighbors:%15d,%15d,%15d,%15d,%15d\n',train.Biowin.model.set.K, res.ReadyBiodeg_Exp_neighbor(i,1:5));
                        fprintf(output(j),'Pred of the %i nearest neighbors:%14d,%15d,%15d,%15d,%15d\n\n',train.Biowin.model.set.K, res.ReadyBiodeg_pred_neighbor(i,1:5));
                    end

                    
                elseif strcmpi(ext,'.txt') && sep==0
                    
                    
                    %res.Xtest=Xtest;
                    fprintf(output,'\t Molecule %s:\n', MoleculeNames{i});
                    fprintf(output,'ReadyBiodeg predicted= %d\n', res.ReadyBiodeg_pred(i));
                    if res.AD_ReadyBiodeg(i)==1
                        fprintf(output,'AD: inside\n');
                    else
                        fprintf(output,'AD: outside\n');
                    end
                    fprintf(output,'Sim_index= %.2f\n', res.Sim_index_ReadyBiodeg(i));
                    fprintf(output,'Conf_index= %.2f\n', res.Conf_index_ReadyBiodeg(i));
                    %CAS=strjoin(res.ReadyBiodeg_CAS_neighbor(i,1:5),',\t');
                    %CAS=strrep([res.CAS_neighbors(i,1:5)],' ',', ');
                    if neighbors==1
                        fprintf(output,'CAS of the %i nearest neighbors:%15s,%15s,%15s,%15s,%15s\n',train.Biowin.model.set.K, res.ReadyBiodeg_CAS_neighbor{i,1:5});
                        fprintf(output,'Exp of the %i nearest neighbors:%15d,%15d,%15d,%15d,%15d\n',train.Biowin.model.set.K, res.ReadyBiodeg_Exp_neighbor(i,1:5));
                        fprintf(output,'Pred of the %i nearest neighbors:%14d,%15d,%15d,%15d,%15d\n\n',train.Biowin.model.set.K, res.ReadyBiodeg_pred_neighbor(i,1:5));
                    end

                end
            end
            
            
            if sep==1 && strcmpi(ext,'.csv')
                T=struct2table(res);
                if printtDesc==1
                    Xtest=array2table(Xtest,'VariableNames',Desc);
                    
                    T=[T Xtest];
                end
                writetable(T,FileOut{j},'Delimiter',',');%,'QuoteStrings',true);
                fclose(output(j));
                
            elseif sep==0 && printtDesc==1 && strcmpi(ext,'.csv')
                
                
                Xtest(:,ismember(Desc,DescNames))=[];
            
                Desc(ismember(Desc,DescNames))=[];
                
                DescNames=[DescNames Desc];
                
                DescMat=[DescMat Xtest];
            end
            
            if sep==1
              resf.RBioDeg=res;
              clear('res');
            end
                      
            
            %Predict HL values
            case {'hl','loghl'}
            
            
            Desc=train.HL.Desc;
            
            
            if verbose>0
                disp('Predicting LogHL values...');
                disp(['Considered descriptors for HL model: ', num2str(length(Desc))]);
                
            end
            if strcmpi(ext,'.txt') && sep==0
                fprintf(output,'\n\n\t\t\t\t\t Predicting LogHL values... \n\n			============================================================== \n\n');
            end
            
            Xtest=zeros(size(Xin,1),length(Desc));
            
            for i=1:length(Desc)
                for l=1:length(Xin(1,:))
                    if strcmp(Desc(i),Xlabels(l))
                        Xtest(:,i)=Xin(:,l);
                        break;
                    end
                end
            end
            
            pred = nnrpred(Xtest,train.HL.model.set.train,train.HL.model.set.y,train.HL.model.set.K,train.HL.model.set.dist_type,train.HL.model.set.param.pret_type);
            
            res.MoleculeID=MoleculeNames;
            
            res.LogHL_pred(:,1)=pred.y_pred_weighted;
            AD=classical_leverage(train.HL.model.set.train,Xtest,'auto');
            res.AD_HL=abs(AD.inorout-1)';
            
            
             %res.Sim_index=1./(1+nanmedian(pred.dc,2));


%             res.Sim_index=1./(1+median(pred.dc,2));
%             if isnan(res.Sim_index)
%                 res.Sim_index=0;
%             end
            
            res.Sim_index_HL=zeros(size(Xtest,1),1);
            res.Conf_index_HL=zeros(size(Xtest,1),1);
            
            HL_CAS_neighbor=cell(size(Xtest,1),5);
            HL_InChiKey_neighbor=cell(size(Xtest,1),5);
            LogHL_Exp_neighbor=zeros(size(Xtest,1),5);
            LogHL_pred_neighbor=zeros(size(Xtest,1),5);
            
            for i=1:size(Xtest(:,1))
                HL_CAS_neighbor(i,:)=train.HL.CAS(pred.neighbors(i,:));
                HL_InChiKey_neighbor(i,:)=train.HL.InChiKey(pred.neighbors(i,:));
                LogHL_Exp_neighbor(i,:)=train.HL.model.set.y(pred.neighbors(i,:));
                LogHL_pred_neighbor(i,:)=train.HL.model.yc_weighted(pred.neighbors(i,:));
                
%                 rmse=calc_reg_param(res.LogHL_Exp_neighbor(i,:),res.LogHL_pred_neighbor(i,:));
%                 res.Conf_index(i,1)=1/(1+rmse.RMSEC);

                res.Sim_index_HL(i,1)=1./(1+pred.dc(i,~isnan(pred.dc(i,:)))*pred.w(i,~isnan(pred.dc(i,:)))');
                
                if isempty(find(~isnan(pred.dc(i,:)), 1))
                    res.Sim_index_HL(i)=0;
                    res.AD_HL(i)=0;
                end
                
                res.Conf_index_HL(i,1)=1/(1+sqrt(((LogHL_Exp_neighbor(i,:)-LogHL_pred_neighbor(i,:)).^2)*pred.w(i,:)'));
                
                if neighbors==1
                    res.HL_CAS_neighbor(i,:)=HL_CAS_neighbor(i,:);
                    res.HL_InChiKey_neighbor(i,:)=HL_InChiKey_neighbor(i,:);
                    res.LogHL_Exp_neighbor(i,:)=LogHL_Exp_neighbor(i,:);
                    res.LogHL_pred_neighbor(i,:)=LogHL_pred_neighbor(i,:);
                end
                
                if strcmpi(ext,'.txt') && sep==1
   
                    %res.Xtest=Xtest;
                    fprintf(output(j),'\t Molecule %s:\n', MoleculeNames{i});
                    fprintf(output(j),'LogHL predicted= %.3f\n', res.LogHL_pred(i));
                    if res.AD_HL(i)==1
                        fprintf(output(j),'AD: inside\n');
                    else
                        fprintf(output(j),'AD: outside\n');
                    end
                    fprintf(output(j),'Sim_index= %.2f\n', res.Sim_index_HL(i));
                    fprintf(output(j),'Conf_index= %.2f\n', res.Conf_index_HL(i));
                    %CAS=strjoin(res.HL_CAS_neighbor(i,1:5),',\t');
                    %CAS=strrep([res.CAS_neighbors(i,1:5)],' ',', ');
                    if neighbors==1
                        fprintf(output(j),'CAS of the %i nearest neighbors:%15s,%15s,%15s,%15s,%15s\n',train.HL.model.set.K, res.HL_CAS_neighbor{i,1:5});
                        fprintf(output(j),'Exp of the %i nearest neighbors:%15.3f,%15.3f,%15.3f,%15.3f,%15.3f\n',train.HL.model.set.K, res.LogHL_Exp_neighbor(i,1:5));
                        fprintf(output(j),'Pred of the %i nearest neighbors:%14.3f,%15.3f,%15.3f,%15.3f,%15.3f\n\n',train.HL.model.set.K, res.LogHL_pred_neighbor(i,1:5));
                    end

                    
                elseif strcmpi(ext,'.txt') && sep==0
   
                    %res.Xtest=Xtest;
                    fprintf(output,'\t Molecule %s:\n', MoleculeNames{i});
                    fprintf(output,'LogHL predicted= %.3f\n', res.LogHL_pred(i));
                    if res.AD_HL(i)==1
                        fprintf(output,'AD: inside\n');
                    else
                        fprintf(output,'AD: outside\n');
                    end
                    fprintf(output,'Sim_index= %.2f\n', res.Sim_index_HL(i));
                    fprintf(output,'Conf_index= %.2f\n', res.Conf_index_HL(i));
                    %CAS=strjoin(res.HL_CAS_neighbor(i,1:5),',\t');
                    %CAS=strrep([res.CAS_neighbors(i,1:5)],' ',', ');
                    if neighbors==1
                        fprintf(output,'CAS of the %i nearest neighbors:%15s,%15s,%15s,%15s,%15s\n',train.HL.model.set.K, res.HL_CAS_neighbor{i,1:5});
                        fprintf(output,'Exp of the %i nearest neighbors:%15.3f,%15.3f,%15.3f,%15.3f,%15.3f\n',train.HL.model.set.K, res.LogHL_Exp_neighbor(i,1:5));
                        fprintf(output,'Pred of the %i nearest neighbors:%14.3f,%15.3f,%15.3f,%15.3f,%15.3f\n\n',train.HL.model.set.K, res.LogHL_pred_neighbor(i,1:5));
                    end

                end
            end
            
            
            if sep==1 && strcmpi(ext,'.csv')
                T=struct2table(res);
                if printtDesc==1
                    Xtest=array2table(Xtest,'VariableNames',Desc);
                    
                    T=[T Xtest];
                end
                writetable(T,FileOut{j},'Delimiter',',');%,'QuoteStrings',true);
                fclose(output(j));
                
            elseif sep==0 && printtDesc==1 && strcmpi(ext,'.csv')
                
                
                Xtest(:,ismember(Desc,DescNames))=[];
            
                Desc(ismember(Desc,DescNames))=[];
                
                DescNames=[DescNames Desc];
                
                DescMat=[DescMat Xtest];
            end
            
            if sep==1
                resf.HL=res;
              clear('res');
            end
          
            
            %Predict KM values
            case {'km','logkm'}
            
            
            Desc=train.KM.Desc;
            
            
            if verbose>0
                disp('Predicting LogKmHL values...');
                disp(['Considered descriptors for KM model: ', num2str(length(Desc))]);
                
            end
            
            if strcmpi(ext,'.txt') && sep==0
                fprintf(output,'\n\n\t\t\t\t\t Predicting LogKmHL values... \n\n			==============================================================  \n\n');
            end
            
            Xtest=zeros(size(Xin,1),length(Desc));
            
            for i=1:length(Desc)
                for l=1:length(Xin(1,:))
                    if strcmp(Desc(i),Xlabels(l))
                        Xtest(:,i)=Xin(:,l);
                        break;
                    end
                end
            end
            
            pred = nnrpred(Xtest,train.KM.model.set.train,train.KM.model.set.y,train.KM.model.set.K,train.KM.model.set.dist_type,train.KM.model.set.param.pret_type);
            
            res.MoleculeID=MoleculeNames;
            
            res.LogKM_pred(:,1)=pred.y_pred_weighted;
            AD=classical_leverage(train.KM.model.set.train,Xtest,'auto');
            res.AD_KM=abs(AD.inorout-1)';
            
            
             %res.Sim_index=1./(1+nanmedian(pred.dc,2));

%             res.Sim_index=1./(1+median(pred.dc,2));
%             if isnan(res.Sim_index)
%                 res.Sim_index=0;
%             end
            
            res.Sim_index_KM=zeros(size(Xtest,1),1);
            res.Conf_index_KM=zeros(size(Xtest,1),1);
            
            KM_CAS_neighbor=cell(size(Xtest,1),5);
            KM_InChiKey_neighbor=cell(size(Xtest,1),5);
            LogKM_Exp_neighbor=zeros(size(Xtest,1),5);
            LogKM_pred_neighbor=zeros(size(Xtest,1),5);
            
            
            for i=1:size(Xtest(:,1))
                KM_CAS_neighbor(i,:)=train.KM.CAS(pred.neighbors(i,:));
                KM_InChiKey_neighbor(i,:)=train.KM.InChiKey(pred.neighbors(i,:));
                LogKM_Exp_neighbor(i,:)=train.KM.model.set.y(pred.neighbors(i,:));
                LogKM_pred_neighbor(i,:)=train.KM.model.yc_weighted(pred.neighbors(i,:));
                
%                 rmse=calc_reg_param(res.LogKM_Exp_neighbor(i,:),res.LogKM_pred_neighbor(i,:));
%                 res.Conf_index(i,1)=1/(1+rmse.RMSEC);

                res.Sim_index_KM(i,1)=1./(1+pred.dc(i,~isnan(pred.dc(i,:)))*pred.w(i,~isnan(pred.dc(i,:)))');
                
                if isempty(find(~isnan(pred.dc(i,:)), 1))
                    res.Sim_index_KM(i)=0;
                    res.AD_KM(i)=0;
                end
                
                res.Conf_index_KM(i,1)=1/(1+sqrt(((LogKM_Exp_neighbor(i,:)-LogKM_pred_neighbor(i,:)).^2)*pred.w(i,:)'));
                
                if neighbors==1
                    res.KM_CAS_neighbor(i,:)=KM_CAS_neighbor(i,:);
                    res.KM_InChiKey_neighbor(i,:)=KM_InChiKey_neighbor(i,:);
                    res.LogKM_Exp_neighbor(i,:)=LogKM_Exp_neighbor(i,:);
                    res.LogKM_pred_neighbor(i,:)=LogKM_pred_neighbor(i,:);
                end
                
                if strcmpi(ext,'.txt') && sep==1
                    %res.Xtest=Xtest;
                    fprintf(output(j),'\t Molecule %s:\n', MoleculeNames{i});
                    fprintf(output(j),'LogKmHL predicted= %.3f\n', res.LogKM_pred(i));
                    if res.AD_KM(i)==1
                        fprintf(output(j),'AD: inside\n');
                    else
                        fprintf(output(j),'AD: outside\n');
                    end
                    fprintf(output(j),'Sim_index= %.2f\n', res.Sim_index_KM(i));
                    fprintf(output(j),'Conf_index= %.2f\n', res.Conf_index_KM(i));
                    %CAS=strjoin(res.KM_CAS_neighbor(i,1:5),',\t');
                    %CAS=strrep([res.CAS_neighbors(i,1:5)],' ',', ');
                    if neighbors==1
                        fprintf(output(j),'CAS of the %i nearest neighbors:%15s,%15s,%15s,%15s,%15s\n',train.KM.model.set.K, res.KM_CAS_neighbor{i,1:5});
                        fprintf(output(j),'Exp of the %i nearest neighbors:%15.3f,%15.3f,%15.3f,%15.3f,%15.3f\n',train.KM.model.set.K, res.LogKM_Exp_neighbor(i,1:5));
                        fprintf(output(j),'Pred of the %i nearest neighbors:%14.3f,%15.3f,%15.3f,%15.3f,%15.3f\n\n',train.KM.model.set.K, res.LogKM_pred_neighbor(i,1:5));
                    end

                    
                elseif strcmpi(ext,'.txt') && sep==0                    
                    %res.Xtest=Xtest;
                    fprintf(output,'\t Molecule %s:\n', MoleculeNames{i});
                    fprintf(output,'LogKmHL predicted= %.3f\n', res.LogKM_pred(i));
                    if res.AD_KM(i)==1
                        fprintf(output,'AD: inside\n');
                    else
                        fprintf(output,'AD: outside\n');
                    end
                    fprintf(output,'Sim_index= %.2f\n', res.Sim_index_KM(i));
                    fprintf(output,'Conf_index= %.2f\n', res.Conf_index_KM(i));
                    %CAS=strjoin(res.KM_CAS_neighbor(i,1:5),',\t');
                    %CAS=strrep([res.CAS_neighbors(i,1:5)],' ',', ');
                    if neighbors==1
                        fprintf(output,'CAS of the %i nearest neighbors:%15s,%15s,%15s,%15s,%15s\n',train.KM.model.set.K, res.KM_CAS_neighbor{i,1:5});
                        fprintf(output,'Exp of the %i nearest neighbors:%15.3f,%15.3f,%15.3f,%15.3f,%15.3f\n',train.KM.model.set.K, res.LogKM_Exp_neighbor(i,1:5));
                        fprintf(output,'Pred of the %i nearest neighbors:%14.3f,%15.3f,%15.3f,%15.3f,%15.3f\n\n',train.KM.model.set.K, res.LogKM_pred_neighbor(i,1:5));
                    end

                end
            end
            
            
            if sep==1 && strcmpi(ext,'.csv')
                T=struct2table(res);
                if printtDesc==1
                    Xtest=array2table(Xtest,'VariableNames',Desc);
                    
                    T=[T Xtest];
                end
                writetable(T,FileOut{j},'Delimiter',',');%,'QuoteStrings',true);
                fclose(output(j));
                
            elseif sep==0 && printtDesc==1 && strcmpi(ext,'.csv')
                
                
                Xtest(:,ismember(Desc,DescNames))=[];
            
                Desc(ismember(Desc,DescNames))=[];
                
                DescNames=[DescNames Desc];
                
                DescMat=[DescMat Xtest];
            end
            
            if sep==1
              resf.KM=res;
              clear('res');
            end
          
            %Predict KOA values
            case {'koa','logkoa'}
            
            
            Desc=train.KOA.Desc;
            
            
            if verbose>0
                disp('Predicting LogKOA values...');
                disp(['Considered descriptors for KOA model: ', num2str(length(Desc))]);
                
            end
            
            if strcmpi(ext,'.txt') && sep==0
                fprintf(output,'\n\n\t\t\t\t\t Predicting LogKOA values... \n\n			==============================================================  \n\n');
            end
            
            Xtest=zeros(size(Xin,1),length(Desc));
            
            for i=1:length(Desc)
                for l=1:length(Xin(1,:))
                    if strcmp(Desc(i),Xlabels(l))
                        Xtest(:,i)=Xin(:,l);
                        break;
                    end
                end
            end
            
            pred = nnrpred(Xtest,train.KOA.model.set.train,train.KOA.model.set.y,train.KOA.model.set.K,train.KOA.model.set.dist_type,train.KOA.model.set.param.pret_type);
            
            res.MoleculeID=MoleculeNames;
            
            res.LogKOA_pred(:,1)=pred.y_pred_weighted;
            AD=classical_leverage(train.KOA.model.set.train,Xtest,'auto');
            res.AD_KOA=abs(AD.inorout-1)';
            
            
             %res.Sim_index=1./(1+nanmedian(pred.dc,2));

%             res.Sim_index=1./(1+median(pred.dc,2));
%             if isnan(res.Sim_index)
%                 res.Sim_index=0;
%             end
            
            res.Sim_index_KOA=zeros(size(Xtest,1),1);
            res.Conf_index_KOA=zeros(size(Xtest,1),1);
            
            KOA_CAS_neighbor=cell(size(Xtest,1),5);
            KOA_InChiKey_neighbor=cell(size(Xtest,1),5);
            LogKOA_Exp_neighbor=zeros(size(Xtest,1),5);
            LogKOA_pred_neighbor=zeros(size(Xtest,1),5);
            
            for i=1:size(Xtest(:,1))
                KOA_CAS_neighbor(i,:)=train.KOA.CAS(pred.neighbors(i,:));
                KOA_InChiKey_neighbor(i,:)=train.KOA.InChiKey(pred.neighbors(i,:));
                LogKOA_Exp_neighbor(i,:)=train.KOA.model.set.y(pred.neighbors(i,:));
                LogKOA_pred_neighbor(i,:)=train.KOA.model.yc_weighted(pred.neighbors(i,:));
                
%                 rmse=calc_reg_param(res.LogKOA_Exp_neighbor(i,:),res.LogKOA_pred_neighbor(i,:));
%                 res.Conf_index(i,1)=1/(1+rmse.RMSEC);

                res.Sim_index_KOA(i,1)=1./(1+pred.dc(i,~isnan(pred.dc(i,:)))*pred.w(i,~isnan(pred.dc(i,:)))');
                
                if isempty(find(~isnan(pred.dc(i,:)), 1))
                    res.Sim_index_KOA(i)=0;
                    res.AD_KOA(i)=0;
                end
                
                res.Conf_index_KOA(i,1)=1/(1+sqrt(((LogKOA_Exp_neighbor(i,:)-LogKOA_pred_neighbor(i,:)).^2)*pred.w(i,:)'));
                if neighbors==1
                    res.KOA_CAS_neighbor(i,:)=KOA_CAS_neighbor(i,:);
                    res.KOA_InChiKey_neighbor(i,:)=KOA_InChiKey_neighbor(i,:);
                    res.LogKOA_Exp_neighbor(i,:)=LogKOA_Exp_neighbor(i,:);
                    res.LogKOA_pred_neighbor(i,:)=LogKOA_pred_neighbor(i,:);
                end
                
                if strcmpi(ext,'.txt') && sep==1 
                    %res.Xtest=Xtest;
                    fprintf(output(j),'\t Molecule %s:\n', MoleculeNames{i});
                    fprintf(output(j),'LogKOA predicted= %.3f\n', res.LogKOA_pred(i));
                    if res.AD_KOA(i)==1
                        fprintf(output(j),'AD: inside\n');
                    else
                        fprintf(output(j),'AD: outside\n');
                    end
                    fprintf(output(j),'Sim_index= %.2f\n', res.Sim_index_KOA(i));
                    fprintf(output(j),'Conf_index= %.2f\n', res.Conf_index_KOA(i));
                    %CAS=strjoin(res.KOA_CAS_neighbor(i,1:5),',\t');
                    %CAS=strrep([res.CAS_neighbors(i,1:5)],' ',', ');
                    if neighbors==1
                        fprintf(output(j),'CAS of the %i nearest neighbors:%15s,%15s,%15s,%15s,%15s\n',train.KOA.model.set.K, res.KOA_CAS_neighbor{i,1:5});
                        fprintf(output(j),'Exp of the %i nearest neighbors:%15.3f,%15.3f,%15.3f,%15.3f,%15.3f\n',train.KOA.model.set.K, res.LogKOA_Exp_neighbor(i,1:5));
                        fprintf(output(j),'Pred of the %i nearest neighbors:%14.3f,%15.3f,%15.3f,%15.3f,%15.3f\n\n',train.KOA.model.set.K, res.LogKOA_pred_neighbor(i,1:5));
                    end
                    
                elseif strcmpi(ext,'.txt') && sep==0

                    %res.Xtest=Xtest;
                    fprintf(output,'\t Molecule %s:\n', MoleculeNames{i});
                    fprintf(output,'LogKOA predicted= %.3f\n', res.LogKOA_pred(i));
                    if res.AD_KOA(i)==1
                        fprintf(output,'AD: inside\n');
                    else
                        fprintf(output,'AD: outside\n');
                    end
                    fprintf(output,'Sim_index= %.2f\n', res.Sim_index_KOA(i));
                    fprintf(output,'Conf_index= %.2f\n', res.Conf_index_KOA(i));
                    %CAS=strjoin(res.KOA_CAS_neighbor(i,1:5),',\t');
                    %CAS=strrep([res.CAS_neighbors(i,1:5)],' ',', ');
                    if neighbors==1
                        fprintf(output,'CAS of the %i nearest neighbors:%15s,%15s,%15s,%15s,%15s\n',train.KOA.model.set.K, res.KOA_CAS_neighbor{i,1:5});
                        fprintf(output,'Exp of the %i nearest neighbors:%15.3f,%15.3f,%15.3f,%15.3f,%15.3f\n',train.KOA.model.set.K, res.LogKOA_Exp_neighbor(i,1:5));
                        fprintf(output,'Pred of the %i nearest neighbors:%14.3f,%15.3f,%15.3f,%15.3f,%15.3f\n\n',train.KOA.model.set.K, res.LogKOA_pred_neighbor(i,1:5));
                    end

                end
            end
            
            
            if sep==1 && strcmpi(ext,'.csv')
                T=struct2table(res);
                if printtDesc==1
                    Xtest=array2table(Xtest,'VariableNames',Desc);
                    
                    T=[T Xtest];
                end
                writetable(T,FileOut{j},'Delimiter',',');%,'QuoteStrings',true);
                fclose(output(j));
                
            elseif sep==0 && printtDesc==1 && strcmpi(ext,'.csv')
                
                
                Xtest(:,ismember(Desc,DescNames))=[];
            
                Desc(ismember(Desc,DescNames))=[];
                
                DescNames=[DescNames Desc];
                
                DescMat=[DescMat Xtest];
            end
            
            if sep==1
              resf.KOA=res;
              clear('res');
            end
          
                        
            %Predict PC values
            case {'pc','logkoc','koc'}
            
            
            Desc=train.PC.Desc;
            
            
            if verbose>0
                disp('Predicting LogKoc values...');
                disp(['Considered descriptors for Koc model: ', num2str(length(Desc))]);
                
            end
            
            if strcmpi(ext,'.txt') && sep==0
                fprintf(output,'\n\n\t\t\t\t\t Predicting LogKoc values... \n\n			==============================================================  \n\n');
            end
            
            Xtest=zeros(size(Xin,1),length(Desc));
            
            for i=1:length(Desc)
                for l=1:length(Xin(1,:))
                    if strcmp(Desc(i),Xlabels(l))
                        Xtest(:,i)=Xin(:,l);
                        break;
                    end
                end
            end
            
            pred = nnrpred(Xtest,train.PC.model.set.train,train.PC.model.set.y,train.PC.model.set.K,train.PC.model.set.dist_type,train.PC.model.set.param.pret_type);
            
            res.MoleculeID=MoleculeNames;
            
            res.LogKoc_pred(:,1)=pred.y_pred_weighted;
            AD=classical_leverage(train.PC.model.set.train,Xtest,'auto');
            res.AD_LogKoc=abs(AD.inorout-1)';
            
            
            
             %res.Sim_index=1./(1+median(pred.dc(~isnan(pred.dc)),2));


%             res.Sim_index=1./(1+median(pred.dc,2));
%             if isnan(res.Sim_index)
%                 res.Sim_index=0;
%             end
            
            
            res.Sim_index_LogKoc=zeros(size(Xtest,1),1);
            res.Conf_index_LogKoc=zeros(size(Xtest,1),1);
            
            Koc_CAS_neighbor=cell(size(Xtest,1),5);
            Koc_InChiKey_neighbor=cell(size(Xtest,1),5);
            LogKoc_Exp_neighbor=zeros(size(Xtest,1),5);
            LogKoc_pred_neighbor=zeros(size(Xtest,1),5);
            
            
            for i=1:size(Xtest(:,1))
                Koc_CAS_neighbor(i,:)=train.PC.CAS(pred.neighbors(i,:));
                Koc_InChiKey_neighbor(i,:)=train.PC.InChiKey(pred.neighbors(i,:));
                LogKoc_Exp_neighbor(i,:)=train.PC.model.set.y(pred.neighbors(i,:));
                LogKoc_pred_neighbor(i,:)=train.PC.model.yc_weighted(pred.neighbors(i,:));
                
%                 rmse=calc_reg_param(res.LogKoc_Exp_neighbor(i,:),res.LogKoc_pred_neighbor(i,:));
%                 res.Conf_index(i,1)=1/(1+rmse.RMSEC);

                res.Sim_index_LogKoc(i,1)=1./(1+pred.dc(i,~isnan(pred.dc(i,:)))*pred.w(i,~isnan(pred.dc(i,:)))');
                
                if isempty(find(~isnan(pred.dc(i,:)), 1))
                    res.Sim_index_LogKoc(i)=0;
                    res.AD_LogKoc(i)=0;
                end
                
                res.Conf_index_LogKoc(i,1)=1/(1+sqrt(((LogKoc_Exp_neighbor(i,:)-LogKoc_pred_neighbor(i,:)).^2)*pred.w(i,:)'));
                if neighbors==1
                    res.Koc_CAS_neighbor(i,:)=Koc_CAS_neighbor(i,:);
                    res.Koc_InChiKey_neighbor(i,:)=Koc_InChiKey_neighbor(i,:);
                    res.LogKoc_Exp_neighbor(i,:)=LogKoc_Exp_neighbor(i,:);
                    res.LogKoc_pred_neighbor(i,:)=LogKoc_pred_neighbor(i,:);
                end
                
                if strcmpi(ext,'.txt') && sep==1
                    %res.Xtest=Xtest;
                    fprintf(output(j),'\t Molecule %s:\n', MoleculeNames{i});
                    fprintf(output(j),'LogKOC predicted= %.3f\n', res.LogKoc_pred(i));
                    if res.AD_LogKoc(i)==1
                        fprintf(output(j),'AD: inside\n');
                    else
                        fprintf(output(j),'AD: outside\n');
                    end
                    fprintf(output(j),'Sim_index= %.2f\n', res.Sim_index_LogKoc(i));
                    fprintf(output(j),'Conf_index= %.2f\n', res.Conf_index_LogKoc(i));
                    %CAS=strjoin(res.Koc_CAS_neighbor(i,1:5),',\t');
                    %CAS=strrep([res.CAS_neighbors(i,1:5)],' ',', ');
                    if neighbors==1
                        fprintf(output(j),'CAS of the %i nearest neighbors:%15s,%15s,%15s,%15s,%15s\n',train.PC.model.set.K, res.Koc_CAS_neighbor{i,1:5});
                        fprintf(output(j),'Exp of the %i nearest neighbors:%15.3f,%15.3f,%15.3f,%15.3f,%15.3f\n',train.PC.model.set.K, res.LogKoc_Exp_neighbor(i,1:5));
                        fprintf(output(j),'Pred of the %i nearest neighbors:%14.3f,%15.3f,%15.3f,%15.3f,%15.3f\n\n',train.PC.model.set.K, res.LogKoc_pred_neighbor(i,1:5));
                    end

                    
                elseif strcmpi(ext,'.txt') && sep==0
                    
                    
                    %res.Xtest=Xtest;
                    fprintf(output,'\t Molecule %s:\n', MoleculeNames{i});
                    fprintf(output,'LogKOC predicted= %.3f\n', res.LogKoc_pred(i));
                    if res.AD_LogKoc(i)==1
                        fprintf(output,'AD: inside\n');
                    else
                        fprintf(output,'AD: outside\n');
                    end
                    fprintf(output,'Sim_index= %.2f\n', res.Sim_index_LogKoc(i));
                    fprintf(output,'Conf_index= %.2f\n', res.Conf_index_LogKoc(i));
                    %CAS=strjoin(res.Koc_CAS_neighbor(i,1:5),',\t');
                    %CAS=strrep([res.CAS_neighbors(i,1:5)],' ',', ');
                    if neighbors==1
                        fprintf(output,'CAS of the %i nearest neighbors:%15s,%15s,%15s,%15s,%15s\n',train.PC.model.set.K, res.Koc_CAS_neighbor{i,1:5});
                        fprintf(output,'Exp of the %i nearest neighbors:%15.3f,%15.3f,%15.3f,%15.3f,%15.3f\n',train.PC.model.set.K, res.LogKoc_Exp_neighbor(i,1:5));
                        fprintf(output,'Pred of the %i nearest neighbors:%14.3f,%15.3f,%15.3f,%15.3f,%15.3f\n\n',train.PC.model.set.K, res.LogKoc_pred_neighbor(i,1:5));
                    end

                end
            end
            
            
            if sep==1 && strcmpi(ext,'.csv')
                T=struct2table(res);
                if printtDesc==1
                    Xtest=array2table(Xtest,'VariableNames',Desc);
                    
                    T=[T Xtest];
                end
                writetable(T,FileOut{j},'Delimiter',',');%,'QuoteStrings',true);
                fclose(output(j));
                
            elseif sep==0 && printtDesc==1 && strcmpi(ext,'.csv')
                
                
                Xtest(:,ismember(Desc,DescNames))=[];
            
                Desc(ismember(Desc,DescNames))=[];
                
                DescNames=[DescNames Desc];
                
                DescMat=[DescMat Xtest];
            end
            
            if sep==1
              resf.KOC=res;
              clear('res');
            end
          
    end
end


if sep==0 && strcmpi(ext,'.csv')
    res=struct2table(res);
    if printtDesc==1;
        
        DescMat=array2table(DescMat,'VariableNames',DescNames);
        res=[res DescMat];
    end
    writetable(res,FileOut,'Delimiter',',');%,'QuoteStrings',true);
    fclose(output);
end

if sep==1
    res=resf;
end


if verbose>0
    disp('End of calculation');
    fprintf('%i molecules predicted\n', length(MoleculeNames));
end


else
    res=0;
end


