function D= nnr_calc_dist(X,Xtest,dist_type,pret_type)

% version 2.0 - February 2012
% Kamel Mansouri
% Milano Chemometrics and QSAR Research Group
% www.disat.unimib.it/chm



n=size(X,1);
m=size(Xtest,1);
D=ones(m,n);

for i=1:size(Xtest,1)
    
    if strcmp(dist_type,'euclidean')
        x_in = Xtest(i,:);
        D_squares_x = (sum(x_in'.^2))'*ones(1,size(X,1));
        D_squares_w = sum(X'.^2);
        D_product   = - 2*(x_in*X');
        D(i,:) = real((D_squares_x + D_squares_w + D_product).^0.5);
    else
        if strcmp(pret_type,'fp')
            A=sum(Xtest(i,:));
            onA=find(Xtest(i,:));
            %offA=find(Xtest(i,:)==0);
        end
        for j=1:size(X,1)
            
            % D(i,j) = 0;
            if strcmp(pret_type,'fp')
                B=sum(X(j,:));
                onB=find(X(j,:));
                % offB=find(X(j,:)==0);
                
                a=0;b=0;c=0;d=0;
                p=size(X,2);
                %D(i,j)=1;
                if A~=0 && B~=0
%                     for k=1:A
%                         for l=1:B
%                             if onB(l)==onA(k)
%                                 a=a+1;
%                             end
%                         end
%                     end
                   if A <B
                        for k=1:A
                            %if ~isempty(find(onA(1,:)==onB(1,k)),1)
                            if any(onB(1,:)==onA(1,k))
                                a=a+1;
                            end
                            
                        end
                    else
                         for l=1:B
                            if any(onA(1,:)==onB(1,l))
                                a=a+1;
                            end
                            
                        end
                   end
                    
                    
                    b=A-a;
                    c=B-a;
                    d=p-(a+b+c);
                else a =0; d=min(A,B);
                    if A==0
                        c=B; b=0;
                    else
                        b=B; c=0;
                    end
                end
                if strcmp(dist_type,'sm')
                    D(i,j)=1-((a+d)/p);
                elseif strcmp(dist_type,'rt')
                    D(i,j)=1-((a+d)/(p+b+c));
                elseif strcmp(dist_type,'jt')
                    D(i,j)=1-(a/(a+b+c));
                elseif strcmp(dist_type,'gle')
                    D(i,j)=1-(2*a/(2*a+b+c));
                elseif strcmp(dist_type,'ct4')
                    D(i,j)=1-(log2(1+a)/log2(1+a+b+c));
                elseif strcmp(dist_type,'ac')
                    D(i,j)=1-((2/pi)*asin(sqrt((a+d)/p)));
                end
                
            else
                x = Xtest(i,:);
                y = X(j,:);
                if strcmp(dist_type,'mahalanobis')
                    D(i,j) = ((x - y)*pinv(cov(X))*(x - y)')^0.5;
                elseif strcmp(dist_type,'cityblock')
                    D(i,j) = sum(abs(x - y));
                elseif strcmp(dist_type,'minkowski')
                    p = 2;
                    D(i,j) = (sum((abs(x - y)).^p))^(1/p);
                end
            end
        end
    end
end
