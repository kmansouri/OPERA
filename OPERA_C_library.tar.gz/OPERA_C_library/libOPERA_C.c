/*
 * MATLAB Compiler: 6.6 (R2018a)
 * Date: Wed Nov 14 22:57:40 2018
 * Arguments:
 * "-B""macro_default""-W""lib:libOPERA_C""-T""link:lib""-d""/home/kmansouri/Doc
 * uments/Shared/work/OPERA/Modeling/13Prop/libOPERA_C/for_testing""-v""/home/km
 * ansouri/Documents/Shared/work/OPERA/Modeling/13Prop/OPERA.m"
 */

#include <stdio.h>
#define EXPORTING_libOPERA_C 1
#include "libOPERA_C.h"

static HMCRINSTANCE _mcr_inst = NULL;

#ifdef __cplusplus
extern "C" {
#endif

static int mclDefaultPrintHandler(const char *s)
{
    return mclWrite(1 /* stdout */, s, sizeof(char)*strlen(s));
}

#ifdef __cplusplus
} /* End extern "C" block */
#endif

#ifdef __cplusplus
extern "C" {
#endif

static int mclDefaultErrorHandler(const char *s)
{
    int written = 0;
    size_t len = 0;
    len = strlen(s);
    written = mclWrite(2 /* stderr */, s, sizeof(char)*len);
    if (len > 0 && s[ len-1 ] != '\n')
        written += mclWrite(2 /* stderr */, "\n", sizeof(char));
    return written;
}

#ifdef __cplusplus
} /* End extern "C" block */
#endif

/* This symbol is defined in shared libraries. Define it here
 * (to nothing) in case this isn't a shared library. 
 */
#ifndef LIB_libOPERA_C_C_API
#define LIB_libOPERA_C_C_API /* No special import/export declaration */
#endif

LIB_libOPERA_C_C_API 
bool MW_CALL_CONV libOPERA_CInitializeWithHandlers(
    mclOutputHandlerFcn error_handler,
    mclOutputHandlerFcn print_handler)
{
    int bResult = 0;
    if (_mcr_inst != NULL)
        return true;
    if (!mclmcrInitialize())
        return false;
    {
        mclCtfStream ctfStream = 
            mclGetEmbeddedCtfStream((void *)(libOPERA_CInitializeWithHandlers));
        if (ctfStream) {
            bResult = mclInitializeComponentInstanceEmbedded(&_mcr_inst,
                                                             error_handler, 
                                                             print_handler,
                                                             ctfStream);
            mclDestroyStream(ctfStream);
        } else {
            bResult = 0;
        }
    }  
    if (!bResult)
    return false;
    return true;
}

LIB_libOPERA_C_C_API 
bool MW_CALL_CONV libOPERA_CInitialize(void)
{
    return libOPERA_CInitializeWithHandlers(mclDefaultErrorHandler, 
                                          mclDefaultPrintHandler);
}

LIB_libOPERA_C_C_API 
void MW_CALL_CONV libOPERA_CTerminate(void)
{
    if (_mcr_inst != NULL)
        mclTerminateInstance(&_mcr_inst);
}

LIB_libOPERA_C_C_API 
void MW_CALL_CONV libOPERA_CPrintStackTrace(void) 
{
    char** stackTrace;
    int stackDepth = mclGetStackTrace(&stackTrace);
    int i;
    for(i=0; i<stackDepth; i++)
    {
        mclWrite(2 /* stderr */, stackTrace[i], sizeof(char)*strlen(stackTrace[i]));
        mclWrite(2 /* stderr */, "\n", sizeof(char)*strlen("\n"));
    }
    mclFreeStackTrace(&stackTrace, stackDepth);
}


LIB_libOPERA_C_C_API 
bool MW_CALL_CONV mlxOPERA(int nlhs, mxArray *plhs[], int nrhs, mxArray *prhs[])
{
    return mclFeval(_mcr_inst, "OPERA", nlhs, plhs, nrhs, prhs);
}

LIB_libOPERA_C_C_API 
bool MW_CALL_CONV mlfOPERA(int nargout, mxArray** res, mxArray* varargin)
{
    return mclMlfFeval(_mcr_inst, "OPERA", nargout, 1, -1, res, varargin);
}

