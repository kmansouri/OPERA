/*
 * MATLAB Compiler: 5.0 (R2013b)
 * Date: Tue Dec  6 16:25:25 2016
 * Arguments: "-B" "macro_default" "-W" "lib:OPERA" "-T" "link:lib" "-d"
 * "/media/Library/Net
 * MyDocuments/work/OPERA/Modeling/13Prop/OPERA/for_testing" "-v"
 * "/media/Library/Net MyDocuments/work/OPERA/Modeling/13Prop/OPERA.m"
 * "class{Class1:/media/Library/Net
 * MyDocuments/work/OPERA/Modeling/13Prop/OPERA.m}" "-a" "/media/Library/Net
 * MyDocuments/work/OPERA/Modeling/13Prop/help.txt" 
 */

#ifndef __OPERA_h
#define __OPERA_h 1

#if defined(__cplusplus) && !defined(mclmcrrt_h) && defined(__linux__)
#  pragma implementation "mclmcrrt.h"
#endif
#include "mclmcrrt.h"
#ifdef __cplusplus
extern "C" {
#endif

#if defined(__SUNPRO_CC)
/* Solaris shared libraries use __global, rather than mapfiles
 * to define the API exported from a shared library. __global is
 * only necessary when building the library -- files including
 * this header file to use the library do not need the __global
 * declaration; hence the EXPORTING_<library> logic.
 */

#ifdef EXPORTING_OPERA
#define PUBLIC_OPERA_C_API __global
#else
#define PUBLIC_OPERA_C_API /* No import statement needed. */
#endif

#define LIB_OPERA_C_API PUBLIC_OPERA_C_API

#elif defined(_HPUX_SOURCE)

#ifdef EXPORTING_OPERA
#define PUBLIC_OPERA_C_API __declspec(dllexport)
#else
#define PUBLIC_OPERA_C_API __declspec(dllimport)
#endif

#define LIB_OPERA_C_API PUBLIC_OPERA_C_API


#else

#define LIB_OPERA_C_API

#endif

/* This symbol is defined in shared libraries. Define it here
 * (to nothing) in case this isn't a shared library. 
 */
#ifndef LIB_OPERA_C_API 
#define LIB_OPERA_C_API /* No special import/export declaration */
#endif

extern LIB_OPERA_C_API 
bool MW_CALL_CONV OPERAInitializeWithHandlers(
       mclOutputHandlerFcn error_handler, 
       mclOutputHandlerFcn print_handler);

extern LIB_OPERA_C_API 
bool MW_CALL_CONV OPERAInitialize(void);

extern LIB_OPERA_C_API 
void MW_CALL_CONV OPERATerminate(void);



extern LIB_OPERA_C_API 
void MW_CALL_CONV OPERAPrintStackTrace(void);

extern LIB_OPERA_C_API 
bool MW_CALL_CONV mlxOPERA(int nlhs, mxArray *plhs[], int nrhs, mxArray *prhs[]);



extern LIB_OPERA_C_API bool MW_CALL_CONV mlfOPERA(int nargout, mxArray** res, mxArray* varargin);

#ifdef __cplusplus
}
#endif
#endif
