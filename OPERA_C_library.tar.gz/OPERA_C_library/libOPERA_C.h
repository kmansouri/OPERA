/*
 * MATLAB Compiler: 6.6 (R2018a)
 * Date: Wed Nov 14 22:57:40 2018
 * Arguments:
 * "-B""macro_default""-W""lib:libOPERA_C""-T""link:lib""-d""/home/kmansouri/Doc
 * uments/Shared/work/OPERA/Modeling/13Prop/libOPERA_C/for_testing""-v""/home/km
 * ansouri/Documents/Shared/work/OPERA/Modeling/13Prop/OPERA.m"
 */

#ifndef __libOPERA_C_h
#define __libOPERA_C_h 1

#if defined(__cplusplus) && !defined(mclmcrrt_h) && defined(__linux__)
#  pragma implementation "mclmcrrt.h"
#endif
#include "mclmcrrt.h"
#ifdef __cplusplus
extern "C" {
#endif

/* This symbol is defined in shared libraries. Define it here
 * (to nothing) in case this isn't a shared library. 
 */
#ifndef LIB_libOPERA_C_C_API 
#define LIB_libOPERA_C_C_API /* No special import/export declaration */
#endif

/* GENERAL LIBRARY FUNCTIONS -- START */

extern LIB_libOPERA_C_C_API 
bool MW_CALL_CONV libOPERA_CInitializeWithHandlers(
       mclOutputHandlerFcn error_handler, 
       mclOutputHandlerFcn print_handler);

extern LIB_libOPERA_C_C_API 
bool MW_CALL_CONV libOPERA_CInitialize(void);

extern LIB_libOPERA_C_C_API 
void MW_CALL_CONV libOPERA_CTerminate(void);

extern LIB_libOPERA_C_C_API 
void MW_CALL_CONV libOPERA_CPrintStackTrace(void);

/* GENERAL LIBRARY FUNCTIONS -- END */

/* C INTERFACE -- MLX WRAPPERS FOR USER-DEFINED MATLAB FUNCTIONS -- START */

extern LIB_libOPERA_C_C_API 
bool MW_CALL_CONV mlxOPERA(int nlhs, mxArray *plhs[], int nrhs, mxArray *prhs[]);

/* C INTERFACE -- MLX WRAPPERS FOR USER-DEFINED MATLAB FUNCTIONS -- END */

/* C INTERFACE -- MLF WRAPPERS FOR USER-DEFINED MATLAB FUNCTIONS -- START */

extern LIB_libOPERA_C_C_API bool MW_CALL_CONV mlfOPERA(int nargout, mxArray** res, mxArray* varargin);

#ifdef __cplusplus
}
#endif
/* C INTERFACE -- MLF WRAPPERS FOR USER-DEFINED MATLAB FUNCTIONS -- END */

#endif
