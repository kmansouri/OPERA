/*
 * MATLAB Compiler: 6.6 (R2018a)
 * Date: Wed Nov 14 23:01:42 2018
 * Arguments: 
 * "-B""macro_default""-W""java:libOPERA_J,Class1""-T""link:lib""-d""/home/kmansouri/Documents/Shared/work/OPERA/Modeling/13Prop/libOPERA_J/for_testing""class{Class1:/home/kmansouri/Documents/Shared/work/OPERA/Modeling/13Prop/OPERA.m}"
 */

package libOPERA_J;

import com.mathworks.toolbox.javabuilder.pooling.Poolable;
import java.util.List;
import java.rmi.Remote;
import java.rmi.RemoteException;

/**
 * The <code>Class1Remote</code> class provides a Java RMI-compliant interface to MATLAB 
 * functions. The interface is compiled from the following files:
 * <pre>
 *  /home/kmansouri/Documents/Shared/work/OPERA/Modeling/13Prop/OPERA.m
 * </pre>
 * The {@link #dispose} method <b>must</b> be called on a <code>Class1Remote</code> 
 * instance when it is no longer needed to ensure that native resources allocated by this 
 * class are properly freed, and the server-side proxy is unexported.  (Failure to call 
 * dispose may result in server-side threads not being properly shut down, which often 
 * appears as a hang.)  
 *
 * This interface is designed to be used together with 
 * <code>com.mathworks.toolbox.javabuilder.remoting.RemoteProxy</code> to automatically 
 * generate RMI server proxy objects for instances of libOPERA_J.Class1.
 */
public interface Class1Remote extends Poolable
{
    /**
     * Provides the standard interface for calling the <code>OPERA</code> MATLAB function 
     * with 1 input argument.  
     *
     * Input arguments to standard interface methods may be passed as sub-classes of 
     * <code>com.mathworks.toolbox.javabuilder.MWArray</code>, or as arrays of any 
     * supported Java type (i.e. scalars and multidimensional arrays of any numeric, 
     * boolean, or character type, or String). Arguments passed as Java types are 
     * converted to MATLAB arrays according to default conversion rules.
     *
     * All inputs to this method must implement either Serializable (pass-by-value) or 
     * Remote (pass-by-reference) as per the RMI specification.
     *
     * Documentation as provided by the author of the MATLAB function:
     * <pre>
     * %%
     * %
     * %        __________________________________________________________________
     * %       |                                                                  |
     * %       |   OPERA models for physchem and environmental fate properties.   |
     * %       |                 Version 1.5 (September 2017)                     |
     * %       |__________________________________________________________________|      
     * % 
     * % 
     * %OPERA is a command line application developed in Matlab providing QSAR models 
     * predictions as well as 
     * %applicability domain and accuracy assessment. All models are built on curated 
     * data from public domain. 
     * %Molecular descriptors are calculated using PaDEL software.
     * %
     * %  Usage: ./run_OPERA.sh <mcr_directory> <argument_list>
     * %  By default, all endpoints will be calculated.
     * %  Examples: 
     * %  ./run_OPERA.sh /mathworks/home/application/v82 -s Sample_50.sdf -o 
     * predictions.csv -a -x -n -v 2
     * %  ./run_OPERA.sh /mathworks/home/application/v82 -d Sample_50.csv -o 
     * predictions.txt -e logP BCF -v 1
     * %
     * %Input: 
     * %  -s, --SDF, --MOL, --SMI  Structure file containing the molecule(s) to be 
     * %                           predicted. IDs will be assigned if the file does not 
     * contain molecule names.
     * %                           Molecular descriptors will be calculated using
     * %                           PaDEL software. Use V2000 SDF.
     * %  -d, --Descriptors        pre-calculated PaDEL descriptors in csv file. If the 
     * first column is not 
     * %                           "Name" as the standard PaDEL output, molecule IDs will 
     * be assinged.
     * %  -m, --Mat, --ascii       Matlab matrix or ascii file containing PaDEL 
     * descriptors.
     * %  -i, --MolID              Molecule names in csv file.
     * %  -t, --SaltInfo           Salt IDs to improve melting point predictions. List 
     * provided in Salts.xls
     * %  -l, --Labels             Descriptor labels. Necessary if the descriptor file 
     * does not contain labels 
     * %                           or contains more than the 1444 PaDEL 2D descriptors.
     * %
     * %Output:
     * %  -o, --Output             Output file containing the predictions, applicability 
     * domain and accuracy 
     * %                           information. File extension could be csv or txt. The 
     * output will contain by default: 
     * %                           Molecule ID, predicted value (pred), Applicability 
     * domain (AD), Similarity index 
     * %                           (Sim_index) and accuracy estimate (Conf_index).
     * %  -n, --Neighbors          Add 5 nearest neighbors from training set (CAS, 
     * InCHiKeys, Observed and predicted values)
     * %  -O, --FullOutput         Output file containing all prediction details and used 
     * descriptors in csv format.
     * %  -x, --Seperate           Separate output file for each endpoint. 
     * %
     * %Miscellaneous:
     * %  -v, --Verbose            Verbose level: 0=silent (default), 1=minimum details, 
     * %  2=full details.
     * %  -a, --All                All endpoints to be calculated. Default.
     * %  -c, --Clean              Remove temporary files (generated during descriptor 
     * calculation.)
     * %  -e, --Endpoint           List endpoints to be calculated (case insensitive). 
     * 'BCF'/'logBCF','BP','logP','MP',
     * %                           'VP'/'logVP','WS', 'AOH', 'BioDeg', 
     * 'RB'/'ReadyBiodeg','HL'/'logHL','KM'/'logKM',
     * %                           'KOA','Koc'/'logKoc', 'RT'. Space separated.
     * %  -RB, -logP, -BCF...      Endpoints to be calculated.
     * %  -h, --Help               Display this help file and exit.
     * %  -V, --Version            Version of the application
     * %  
     * %
     * %
     * %
     * %Developed by:
     * %Kamel Mansouri
     * %mansourikamel@gmail.com
     * %
     * %Developed at: 
     * %National Center of Computational Toxicology
     * %United States Environmental Protection Agency
     * %109 T.W. Alexander Drive 
     * %Research Triangle Park, NC 27711
     * %
     * %For more information about the models and the data:
     * %[1] Mansouri, K.; Grulke, C. M.; Richard, A. M.; Judson, R. S.; and
     * %Williams, A. j. An Automated curation procedure for adressing chemistry
     * %related errors and inconsistencies in public domain datasets used in QSAR
     * %modeling. SAR and QSAR in Environmental Research.
     * %[2] Mansouri, K.; Grulke, C. M.; Judson, R. S.; and Williams, A. J. 
     * %OPERA models for predicting physicochemical properties and environmental fate 
     * endpoints. 
     * %Journal of Cheminformatics.
     * %[3] Yap CW (2011). PaDEL-Descriptor: An open source software to calculate 
     * molecular descriptors and fingerprints. 
     * %Journal of Computational Chemistry. 32 (7): 1466-1474
     * %[4] CompTox Chemistry Dashboard accessible at:https://comptox.epa.gov/dashboard
     * </pre>
     *
     * @param nargout Number of outputs to return.
     * @param rhs The inputs to the MATLAB function.
     *
     * @return Array of length nargout containing the function outputs. Outputs are 
     * returned as sub-classes of <code>com.mathworks.toolbox.javabuilder.MWArray</code>. 
     * Each output array should be freed by calling its <code>dispose()</code> method.
     *
     * @throws java.rmi.RemoteException An error has occurred during the function call or 
     * in communication with the server.
     */
    public Object[] OPERA(int nargout, Object... rhs) throws RemoteException;
  
    /** 
     * Frees native resources associated with the remote server object 
     * @throws java.rmi.RemoteException An error has occurred during the function call or in communication with the server.
     */
    void dispose() throws RemoteException;
}
