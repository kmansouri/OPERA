/*
 * MATLAB Compiler: 6.6 (R2018a)
 * Date: Sun Nov 18 11:29:25 2018
 * Arguments: 
 * "-B""macro_default""-W""java:libOPERA_J,Class1""-T""link:lib""-d""/home/kmansouri/Documents/Shared/work/OPERA/Modeling/13Prop/libOPERA_J/for_testing""class{Class1:/home/kmansouri/Documents/Shared/work/OPERA/Modeling/13Prop/OPERA.m}"
 */

package libOPERA_J;

import com.mathworks.toolbox.javabuilder.*;
import com.mathworks.toolbox.javabuilder.internal.*;
import java.util.*;

/**
 * The <code>Class1</code> class provides a Java interface to MATLAB functions. 
 * The interface is compiled from the following files:
 * <pre>
 *  /home/kmansouri/Documents/Shared/work/OPERA/Modeling/13Prop/OPERA.m
 * </pre>
 * The {@link #dispose} method <b>must</b> be called on a <code>Class1</code> instance 
 * when it is no longer needed to ensure that native resources allocated by this class 
 * are properly freed.
 * @version 0.0
 */
public class Class1 extends MWComponentInstance<Class1>
{
    /**
     * Tracks all instances of this class to ensure their dispose method is
     * called on shutdown.
     */
    private static final Set<Disposable> sInstances = new HashSet<Disposable>();

    /**
     * Maintains information used in calling the <code>OPERA</code> MATLAB function.
     */
    private static final MWFunctionSignature sOPERASignature =
        new MWFunctionSignature(/* max outputs = */ 1,
                                /* has varargout = */ false,
                                /* function name = */ "OPERA",
                                /* max inputs = */ 1,
                                /* has varargin = */ true);

    /**
     * Shared initialization implementation - private
     * @throws MWException An error has occurred during the function call.
     */
    private Class1 (final MWMCR mcr) throws MWException
    {
        super(mcr);
        // add this to sInstances
        synchronized(Class1.class) {
            sInstances.add(this);
        }
    }

    /**
     * Constructs a new instance of the <code>Class1</code> class.
     * @throws MWException An error has occurred during the function call.
     */
    public Class1() throws MWException
    {
        this(LibOPERA_JMCRFactory.newInstance());
    }
    
    private static MWComponentOptions getPathToComponentOptions(String path)
    {
        MWComponentOptions options = new MWComponentOptions(new MWCtfExtractLocation(path),
                                                            new MWCtfDirectorySource(path));
        return options;
    }
    
    /**
     * @deprecated Please use the constructor {@link #Class1(MWComponentOptions componentOptions)}.
     * The <code>com.mathworks.toolbox.javabuilder.MWComponentOptions</code> class provides an API to set the
     * path to the component.
     * @param pathToComponent Path to component directory.
     * @throws MWException An error has occurred during the function call.
     */
    public Class1(String pathToComponent) throws MWException
    {
        this(LibOPERA_JMCRFactory.newInstance(getPathToComponentOptions(pathToComponent)));
    }
    
    /**
     * Constructs a new instance of the <code>Class1</code> class. Use this constructor 
     * to specify the options required to instantiate this component.  The options will 
     * be specific to the instance of this component being created.
     * @param componentOptions Options specific to the component.
     * @throws MWException An error has occurred during the function call.
     */
    public Class1(MWComponentOptions componentOptions) throws MWException
    {
        this(LibOPERA_JMCRFactory.newInstance(componentOptions));
    }
    
    /** Frees native resources associated with this object */
    public void dispose()
    {
        try {
            super.dispose();
        } finally {
            synchronized(Class1.class) {
                sInstances.remove(this);
            }
        }
    }
  
    /**
     * Invokes the first MATLAB function specified to MCC, with any arguments given on
     * the command line, and prints the result.
     *
     * @param args arguments to the function
     */
    public static void main (String[] args)
    {
        try {
            MWMCR mcr = LibOPERA_JMCRFactory.newInstance();
            mcr.runMain( sOPERASignature, args);
            mcr.dispose();
        } catch (Throwable t) {
            t.printStackTrace();
        }
    }
    
    /**
     * Calls dispose method for each outstanding instance of this class.
     */
    public static void disposeAllInstances()
    {
        synchronized(Class1.class) {
            for (Disposable i : sInstances) i.dispose();
            sInstances.clear();
        }
    }

    /**
     * Provides the interface for calling the <code>OPERA</code> MATLAB function 
     * where the first argument, an instance of List, receives the output of the MATLAB function and
     * the second argument, also an instance of List, provides the input to the MATLAB function.
     * <p>
     * Description as provided by the author of the MATLAB function:
     * </p>
     * <pre>
     * %%
     * %
     * %        _______________________________________________________________________
     * %       |                                                                       |
     * %       |   OPERA models for physchem, environmental fate and tox properties.   |
     * %       |                 Version 2.0 (November 2018)                           |
     * %       |_______________________________________________________________________|      
     * % 
     * % 
     * %OPERA is a command line application developed in Matlab providing QSAR models 
     * predictions as well as 
     * %applicability domain and accuracy assessment. All models are built on curated 
     * data from public domain. 
     * %Molecular descriptors are calculated using PaDEL and CDK software.
     * %
     * %
     * %Input: 
     * %  -s, --SDF, --MOL, --SMI  Structure file containing the molecule(s) to be 
     * %                           predicted. IDs will be assigned if the file does not 
     * contain molecule names.
     * %                           Molecular descriptors will be calculated using
     * %                           PaDEL software. Use V2000 SDF.
     * %  -d, --Descriptors        pre-calculated PaDEL descriptors in a comma delimited 
     * csv file. If the first column is not 
     * %                           "Name" as the standard PaDEL output, molecule IDs will 
     * be assinged.
     * %  -fp, --fingerprints      pre-calculated descriptors using CDK2.0 in a tab 
     * delimited text file. 
     * %   -cdk, --cdk             pre-calculated fingerprints using PaDEL in a comma 
     * delimited csv file.
     * %  -m, --Mat, --ascii       Matlab matrix or ascii file containing PaDEL 
     * descriptors.
     * %  -i, --MolID              Molecule names in csv file.
     * %  -t, --SaltInfo           Salt IDs to improve melting point predictions. List 
     * provided in Salts.xls
     * %  -l, --Labels             Descriptor labels. Necessary if the descriptor file 
     * does not contain labels 
     * %                           or contains more than the 1444 PaDEL 2D descriptors.
     * %
     * %Output:
     * %  -o, --Output             Output file containing the predictions, applicability 
     * domain and accuracy 
     * %                           information. File extension could be csv or txt. The 
     * output will contain by default: 
     * %                           Molecule ID, predicted value (pred), Applicability 
     * domain (AD), Applicability domain index 
     * %                           (AD_index) and accuracy estimate (Conf_index).
     * %  -n, --Neighbors          Add 5 nearest neighbors from training set (CAS, 
     * InCHiKeys, Observed and predicted values)
     * %  -O, --FullOutput         Output file containing all prediction details and used 
     * descriptors in csv format.
     * %  -x, --Seperate           Separate output file for each endpoint. 
     * %
     * %Miscellaneous:
     * %  -v, --Verbose            Verbose level: 0=silent (default), 1=minimum details, 
     * %  2=full details.
     * %  -a, --All                All endpoints to be calculated. Default.
     * %  -c, --Clean              Remove temporary files (generated during descriptor 
     * calculation.)
     * %  -logP, -BCF...           List endpoints to be calculated (case insensitive). 
     * 'BCF'/'logBCF','BP','logP','MP',
     * %                           'VP'/'logVP','WS', 'AOH', 'BioDeg', 
     * 'RB'/'ReadyBiodeg','HL'/'logHL','KM'/'logKM',
     * %                           'KOA','Koc'/'logKoc', 'RT', 'pKa', 'logD', 
     * 'CERAPP'/'ER', 'CoMPARA'/'AR', 'CATMoS/AcuteTox'.
     * % 							Groups of Endpoints: StrP (Structural properties), PC/Physchem, 
     * EnvFate/EF, Tox (ER, AR, AcuteTox).
     * %  -e, --Endpoint      		List endpoints to be calculated.
     * %  -h, --Help               Display this help file and exit.
     * %  -V, --Version            Version of the application
     * %  
     * %
     * %
     * %
     * %Developed by:
     * %Kamel Mansouri
     * %mansourikamel@gmail.com
     * %
     * %
     * %For more information about the models and the data:
     * %[1] Mansouri, K. et al. SAR and QSAR in Env. Res. (2016). 
     * https://doi.org/10.1080/1062936X.2016.1253611
     * %[2] Mansouri K. et al. J Cheminform (2018) 
     * https://doi.org/10.1186/s13321-018-0263-1.
     * %[3] The CompTox Chemistry Dashboard (https://comptox.epa.gov/dashboard)
     * %[4] Williams A. J. et al. J Cheminform (2017) 
     * https://doi.org/10.1186/s13321-017-0247-6
     * %[5] JRC QSAR Model Database https://qsardb.jrc.ec.europa.eu/qmrf/endpoint
     * </pre>
     * @param lhs List in which to return outputs. Number of outputs (nargout) is
     * determined by allocated size of this List. Outputs are returned as
     * sub-classes of <code>com.mathworks.toolbox.javabuilder.MWArray</code>.
     * Each output array should be freed by calling its <code>dispose()</code>
     * method.
     *
     * @param rhs List containing inputs. Number of inputs (nargin) is determined
     * by the allocated size of this List. Input arguments may be passed as
     * sub-classes of <code>com.mathworks.toolbox.javabuilder.MWArray</code>, or
     * as arrays of any supported Java type. Arguments passed as Java types are
     * converted to MATLAB arrays according to default conversion rules.
     * @throws MWException An error has occurred during the function call.
     */
    public void OPERA(List lhs, List rhs) throws MWException
    {
        fMCR.invoke(lhs, rhs, sOPERASignature);
    }

    /**
     * Provides the interface for calling the <code>OPERA</code> MATLAB function 
     * where the first argument, an Object array, receives the output of the MATLAB function and
     * the second argument, also an Object array, provides the input to the MATLAB function.
     * <p>
     * Description as provided by the author of the MATLAB function:
     * </p>
     * <pre>
     * %%
     * %
     * %        _______________________________________________________________________
     * %       |                                                                       |
     * %       |   OPERA models for physchem, environmental fate and tox properties.   |
     * %       |                 Version 2.0 (November 2018)                           |
     * %       |_______________________________________________________________________|      
     * % 
     * % 
     * %OPERA is a command line application developed in Matlab providing QSAR models 
     * predictions as well as 
     * %applicability domain and accuracy assessment. All models are built on curated 
     * data from public domain. 
     * %Molecular descriptors are calculated using PaDEL and CDK software.
     * %
     * %
     * %Input: 
     * %  -s, --SDF, --MOL, --SMI  Structure file containing the molecule(s) to be 
     * %                           predicted. IDs will be assigned if the file does not 
     * contain molecule names.
     * %                           Molecular descriptors will be calculated using
     * %                           PaDEL software. Use V2000 SDF.
     * %  -d, --Descriptors        pre-calculated PaDEL descriptors in a comma delimited 
     * csv file. If the first column is not 
     * %                           "Name" as the standard PaDEL output, molecule IDs will 
     * be assinged.
     * %  -fp, --fingerprints      pre-calculated descriptors using CDK2.0 in a tab 
     * delimited text file. 
     * %   -cdk, --cdk             pre-calculated fingerprints using PaDEL in a comma 
     * delimited csv file.
     * %  -m, --Mat, --ascii       Matlab matrix or ascii file containing PaDEL 
     * descriptors.
     * %  -i, --MolID              Molecule names in csv file.
     * %  -t, --SaltInfo           Salt IDs to improve melting point predictions. List 
     * provided in Salts.xls
     * %  -l, --Labels             Descriptor labels. Necessary if the descriptor file 
     * does not contain labels 
     * %                           or contains more than the 1444 PaDEL 2D descriptors.
     * %
     * %Output:
     * %  -o, --Output             Output file containing the predictions, applicability 
     * domain and accuracy 
     * %                           information. File extension could be csv or txt. The 
     * output will contain by default: 
     * %                           Molecule ID, predicted value (pred), Applicability 
     * domain (AD), Applicability domain index 
     * %                           (AD_index) and accuracy estimate (Conf_index).
     * %  -n, --Neighbors          Add 5 nearest neighbors from training set (CAS, 
     * InCHiKeys, Observed and predicted values)
     * %  -O, --FullOutput         Output file containing all prediction details and used 
     * descriptors in csv format.
     * %  -x, --Seperate           Separate output file for each endpoint. 
     * %
     * %Miscellaneous:
     * %  -v, --Verbose            Verbose level: 0=silent (default), 1=minimum details, 
     * %  2=full details.
     * %  -a, --All                All endpoints to be calculated. Default.
     * %  -c, --Clean              Remove temporary files (generated during descriptor 
     * calculation.)
     * %  -logP, -BCF...           List endpoints to be calculated (case insensitive). 
     * 'BCF'/'logBCF','BP','logP','MP',
     * %                           'VP'/'logVP','WS', 'AOH', 'BioDeg', 
     * 'RB'/'ReadyBiodeg','HL'/'logHL','KM'/'logKM',
     * %                           'KOA','Koc'/'logKoc', 'RT', 'pKa', 'logD', 
     * 'CERAPP'/'ER', 'CoMPARA'/'AR', 'CATMoS/AcuteTox'.
     * % 							Groups of Endpoints: StrP (Structural properties), PC/Physchem, 
     * EnvFate/EF, Tox (ER, AR, AcuteTox).
     * %  -e, --Endpoint      		List endpoints to be calculated.
     * %  -h, --Help               Display this help file and exit.
     * %  -V, --Version            Version of the application
     * %  
     * %
     * %
     * %
     * %Developed by:
     * %Kamel Mansouri
     * %mansourikamel@gmail.com
     * %
     * %
     * %For more information about the models and the data:
     * %[1] Mansouri, K. et al. SAR and QSAR in Env. Res. (2016). 
     * https://doi.org/10.1080/1062936X.2016.1253611
     * %[2] Mansouri K. et al. J Cheminform (2018) 
     * https://doi.org/10.1186/s13321-018-0263-1.
     * %[3] The CompTox Chemistry Dashboard (https://comptox.epa.gov/dashboard)
     * %[4] Williams A. J. et al. J Cheminform (2017) 
     * https://doi.org/10.1186/s13321-017-0247-6
     * %[5] JRC QSAR Model Database https://qsardb.jrc.ec.europa.eu/qmrf/endpoint
     * </pre>
     * @param lhs array in which to return outputs. Number of outputs (nargout)
     * is determined by allocated size of this array. Outputs are returned as
     * sub-classes of <code>com.mathworks.toolbox.javabuilder.MWArray</code>.
     * Each output array should be freed by calling its <code>dispose()</code>
     * method.
     *
     * @param rhs array containing inputs. Number of inputs (nargin) is
     * determined by the allocated size of this array. Input arguments may be
     * passed as sub-classes of
     * <code>com.mathworks.toolbox.javabuilder.MWArray</code>, or as arrays of
     * any supported Java type. Arguments passed as Java types are converted to
     * MATLAB arrays according to default conversion rules.
     * @throws MWException An error has occurred during the function call.
     */
    public void OPERA(Object[] lhs, Object[] rhs) throws MWException
    {
        fMCR.invoke(Arrays.asList(lhs), Arrays.asList(rhs), sOPERASignature);
    }

    /**
     * Provides the standard interface for calling the <code>OPERA</code> MATLAB function with 
     * 0 or more comma-separated input arguments.
     * Input arguments may be passed as sub-classes of
     * <code>com.mathworks.toolbox.javabuilder.MWArray</code>, or as arrays of
     * any supported Java type. Arguments passed as Java types are converted to
     * MATLAB arrays according to default conversion rules.
     *
     * <p>
     * Description as provided by the author of the MATLAB function:
     * </p>
     * <pre>
     * %%
     * %
     * %        _______________________________________________________________________
     * %       |                                                                       |
     * %       |   OPERA models for physchem, environmental fate and tox properties.   |
     * %       |                 Version 2.0 (November 2018)                           |
     * %       |_______________________________________________________________________|      
     * % 
     * % 
     * %OPERA is a command line application developed in Matlab providing QSAR models 
     * predictions as well as 
     * %applicability domain and accuracy assessment. All models are built on curated 
     * data from public domain. 
     * %Molecular descriptors are calculated using PaDEL and CDK software.
     * %
     * %
     * %Input: 
     * %  -s, --SDF, --MOL, --SMI  Structure file containing the molecule(s) to be 
     * %                           predicted. IDs will be assigned if the file does not 
     * contain molecule names.
     * %                           Molecular descriptors will be calculated using
     * %                           PaDEL software. Use V2000 SDF.
     * %  -d, --Descriptors        pre-calculated PaDEL descriptors in a comma delimited 
     * csv file. If the first column is not 
     * %                           "Name" as the standard PaDEL output, molecule IDs will 
     * be assinged.
     * %  -fp, --fingerprints      pre-calculated descriptors using CDK2.0 in a tab 
     * delimited text file. 
     * %   -cdk, --cdk             pre-calculated fingerprints using PaDEL in a comma 
     * delimited csv file.
     * %  -m, --Mat, --ascii       Matlab matrix or ascii file containing PaDEL 
     * descriptors.
     * %  -i, --MolID              Molecule names in csv file.
     * %  -t, --SaltInfo           Salt IDs to improve melting point predictions. List 
     * provided in Salts.xls
     * %  -l, --Labels             Descriptor labels. Necessary if the descriptor file 
     * does not contain labels 
     * %                           or contains more than the 1444 PaDEL 2D descriptors.
     * %
     * %Output:
     * %  -o, --Output             Output file containing the predictions, applicability 
     * domain and accuracy 
     * %                           information. File extension could be csv or txt. The 
     * output will contain by default: 
     * %                           Molecule ID, predicted value (pred), Applicability 
     * domain (AD), Applicability domain index 
     * %                           (AD_index) and accuracy estimate (Conf_index).
     * %  -n, --Neighbors          Add 5 nearest neighbors from training set (CAS, 
     * InCHiKeys, Observed and predicted values)
     * %  -O, --FullOutput         Output file containing all prediction details and used 
     * descriptors in csv format.
     * %  -x, --Seperate           Separate output file for each endpoint. 
     * %
     * %Miscellaneous:
     * %  -v, --Verbose            Verbose level: 0=silent (default), 1=minimum details, 
     * %  2=full details.
     * %  -a, --All                All endpoints to be calculated. Default.
     * %  -c, --Clean              Remove temporary files (generated during descriptor 
     * calculation.)
     * %  -logP, -BCF...           List endpoints to be calculated (case insensitive). 
     * 'BCF'/'logBCF','BP','logP','MP',
     * %                           'VP'/'logVP','WS', 'AOH', 'BioDeg', 
     * 'RB'/'ReadyBiodeg','HL'/'logHL','KM'/'logKM',
     * %                           'KOA','Koc'/'logKoc', 'RT', 'pKa', 'logD', 
     * 'CERAPP'/'ER', 'CoMPARA'/'AR', 'CATMoS/AcuteTox'.
     * % 							Groups of Endpoints: StrP (Structural properties), PC/Physchem, 
     * EnvFate/EF, Tox (ER, AR, AcuteTox).
     * %  -e, --Endpoint      		List endpoints to be calculated.
     * %  -h, --Help               Display this help file and exit.
     * %  -V, --Version            Version of the application
     * %  
     * %
     * %
     * %
     * %Developed by:
     * %Kamel Mansouri
     * %mansourikamel@gmail.com
     * %
     * %
     * %For more information about the models and the data:
     * %[1] Mansouri, K. et al. SAR and QSAR in Env. Res. (2016). 
     * https://doi.org/10.1080/1062936X.2016.1253611
     * %[2] Mansouri K. et al. J Cheminform (2018) 
     * https://doi.org/10.1186/s13321-018-0263-1.
     * %[3] The CompTox Chemistry Dashboard (https://comptox.epa.gov/dashboard)
     * %[4] Williams A. J. et al. J Cheminform (2017) 
     * https://doi.org/10.1186/s13321-017-0247-6
     * %[5] JRC QSAR Model Database https://qsardb.jrc.ec.europa.eu/qmrf/endpoint
     * </pre>
     * @param nargout Number of outputs to return.
     * @param rhs The inputs to the MATLAB function.
     * @return Array of length nargout containing the function outputs. Outputs
     * are returned as sub-classes of
     * <code>com.mathworks.toolbox.javabuilder.MWArray</code>. Each output array
     * should be freed by calling its <code>dispose()</code> method.
     * @throws MWException An error has occurred during the function call.
     */
    public Object[] OPERA(int nargout, Object... rhs) throws MWException
    {
        Object[] lhs = new Object[nargout];
        fMCR.invoke(Arrays.asList(lhs), 
                    MWMCR.getRhsCompat(rhs, sOPERASignature), 
                    sOPERASignature);
        return lhs;
    }
}
