/*
 * MATLAB Compiler: 6.6 (R2018a)
 * Date: Sun Nov 18 11:29:25 2018
 * Arguments: 
 * "-B""macro_default""-W""java:libOPERA_J,Class1""-T""link:lib""-d""/home/kmansouri/Documents/Shared/work/OPERA/Modeling/13Prop/libOPERA_J/for_testing""class{Class1:/home/kmansouri/Documents/Shared/work/OPERA/Modeling/13Prop/OPERA.m}"
 */

package libOPERA_J;

import com.mathworks.toolbox.javabuilder.*;
import com.mathworks.toolbox.javabuilder.internal.*;

/**
 * <i>INTERNAL USE ONLY</i>
 */
public class LibOPERA_JMCRFactory
{
   
    
    /** Component's uuid */
    private static final String sComponentId = "libOPERA_J_F5F94944918E9CC0BE738B25255E56E9";
    
    /** Component name */
    private static final String sComponentName = "libOPERA_J";
    
   
    /** Pointer to default component options */
    private static final MWComponentOptions sDefaultComponentOptions = 
        new MWComponentOptions(
            MWCtfExtractLocation.EXTRACT_TO_CACHE, 
            new MWCtfClassLoaderSource(LibOPERA_JMCRFactory.class)
        );
    
    
    private LibOPERA_JMCRFactory()
    {
        // Never called.
    }
    
    public static MWMCR newInstance(MWComponentOptions componentOptions) throws MWException
    {
        if (null == componentOptions.getCtfSource()) {
            componentOptions = new MWComponentOptions(componentOptions);
            componentOptions.setCtfSource(sDefaultComponentOptions.getCtfSource());
        }
        return MWMCR.newInstance(
            componentOptions, 
            LibOPERA_JMCRFactory.class, 
            sComponentName, 
            sComponentId,
            new int[]{9,4,0}
        );
    }
    
    public static MWMCR newInstance() throws MWException
    {
        return newInstance(sDefaultComponentOptions);
    }
}
