/*
 * MATLAB Compiler: 6.6 (R2018a)
 * Date: Sun Nov 18 11:29:25 2018
 * Arguments: 
 * "-B""macro_default""-W""java:libOPERA_J,Class1""-T""link:lib""-d""/home/kmansouri/Documents/Shared/work/OPERA/Modeling/13Prop/libOPERA_J/for_testing""class{Class1:/home/kmansouri/Documents/Shared/work/OPERA/Modeling/13Prop/OPERA.m}"
 */

package libOPERA_J;

import com.mathworks.toolbox.javabuilder.pooling.Poolable;
import java.util.List;
import java.rmi.Remote;
import java.rmi.RemoteException;

/**
 * The <code>Class1Remote</code> class provides a Java RMI-compliant interface to MATLAB 
 * functions. The interface is compiled from the following files:
 * <pre>
 *  /home/kmansouri/Documents/Shared/work/OPERA/Modeling/13Prop/OPERA.m
 * </pre>
 * The {@link #dispose} method <b>must</b> be called on a <code>Class1Remote</code> 
 * instance when it is no longer needed to ensure that native resources allocated by this 
 * class are properly freed, and the server-side proxy is unexported.  (Failure to call 
 * dispose may result in server-side threads not being properly shut down, which often 
 * appears as a hang.)  
 *
 * This interface is designed to be used together with 
 * <code>com.mathworks.toolbox.javabuilder.remoting.RemoteProxy</code> to automatically 
 * generate RMI server proxy objects for instances of libOPERA_J.Class1.
 */
public interface Class1Remote extends Poolable
{
    /**
     * Provides the standard interface for calling the <code>OPERA</code> MATLAB function 
     * with 1 input argument.  
     *
     * Input arguments to standard interface methods may be passed as sub-classes of 
     * <code>com.mathworks.toolbox.javabuilder.MWArray</code>, or as arrays of any 
     * supported Java type (i.e. scalars and multidimensional arrays of any numeric, 
     * boolean, or character type, or String). Arguments passed as Java types are 
     * converted to MATLAB arrays according to default conversion rules.
     *
     * All inputs to this method must implement either Serializable (pass-by-value) or 
     * Remote (pass-by-reference) as per the RMI specification.
     *
     * Documentation as provided by the author of the MATLAB function:
     * <pre>
     * %%
     * %
     * %        _______________________________________________________________________
     * %       |                                                                       |
     * %       |   OPERA models for physchem, environmental fate and tox properties.   |
     * %       |                 Version 2.0 (November 2018)                           |
     * %       |_______________________________________________________________________|      
     * % 
     * % 
     * %OPERA is a command line application developed in Matlab providing QSAR models 
     * predictions as well as 
     * %applicability domain and accuracy assessment. All models are built on curated 
     * data from public domain. 
     * %Molecular descriptors are calculated using PaDEL and CDK software.
     * %
     * %
     * %Input: 
     * %  -s, --SDF, --MOL, --SMI  Structure file containing the molecule(s) to be 
     * %                           predicted. IDs will be assigned if the file does not 
     * contain molecule names.
     * %                           Molecular descriptors will be calculated using
     * %                           PaDEL software. Use V2000 SDF.
     * %  -d, --Descriptors        pre-calculated PaDEL descriptors in a comma delimited 
     * csv file. If the first column is not 
     * %                           "Name" as the standard PaDEL output, molecule IDs will 
     * be assinged.
     * %  -fp, --fingerprints      pre-calculated descriptors using CDK2.0 in a tab 
     * delimited text file. 
     * %   -cdk, --cdk             pre-calculated fingerprints using PaDEL in a comma 
     * delimited csv file.
     * %  -m, --Mat, --ascii       Matlab matrix or ascii file containing PaDEL 
     * descriptors.
     * %  -i, --MolID              Molecule names in csv file.
     * %  -t, --SaltInfo           Salt IDs to improve melting point predictions. List 
     * provided in Salts.xls
     * %  -l, --Labels             Descriptor labels. Necessary if the descriptor file 
     * does not contain labels 
     * %                           or contains more than the 1444 PaDEL 2D descriptors.
     * %
     * %Output:
     * %  -o, --Output             Output file containing the predictions, applicability 
     * domain and accuracy 
     * %                           information. File extension could be csv or txt. The 
     * output will contain by default: 
     * %                           Molecule ID, predicted value (pred), Applicability 
     * domain (AD), Applicability domain index 
     * %                           (AD_index) and accuracy estimate (Conf_index).
     * %  -n, --Neighbors          Add 5 nearest neighbors from training set (CAS, 
     * InCHiKeys, Observed and predicted values)
     * %  -O, --FullOutput         Output file containing all prediction details and used 
     * descriptors in csv format.
     * %  -x, --Seperate           Separate output file for each endpoint. 
     * %
     * %Miscellaneous:
     * %  -v, --Verbose            Verbose level: 0=silent (default), 1=minimum details, 
     * %  2=full details.
     * %  -a, --All                All endpoints to be calculated. Default.
     * %  -c, --Clean              Remove temporary files (generated during descriptor 
     * calculation.)
     * %  -logP, -BCF...           List endpoints to be calculated (case insensitive). 
     * 'BCF'/'logBCF','BP','logP','MP',
     * %                           'VP'/'logVP','WS', 'AOH', 'BioDeg', 
     * 'RB'/'ReadyBiodeg','HL'/'logHL','KM'/'logKM',
     * %                           'KOA','Koc'/'logKoc', 'RT', 'pKa', 'logD', 
     * 'CERAPP'/'ER', 'CoMPARA'/'AR', 'CATMoS/AcuteTox'.
     * % 							Groups of Endpoints: StrP (Structural properties), PC/Physchem, 
     * EnvFate/EF, Tox (ER, AR, AcuteTox).
     * %  -e, --Endpoint      		List endpoints to be calculated.
     * %  -h, --Help               Display this help file and exit.
     * %  -V, --Version            Version of the application
     * %  
     * %
     * %
     * %
     * %Developed by:
     * %Kamel Mansouri
     * %mansourikamel@gmail.com
     * %
     * %
     * %For more information about the models and the data:
     * %[1] Mansouri, K. et al. SAR and QSAR in Env. Res. (2016). 
     * https://doi.org/10.1080/1062936X.2016.1253611
     * %[2] Mansouri K. et al. J Cheminform (2018) 
     * https://doi.org/10.1186/s13321-018-0263-1.
     * %[3] The CompTox Chemistry Dashboard (https://comptox.epa.gov/dashboard)
     * %[4] Williams A. J. et al. J Cheminform (2017) 
     * https://doi.org/10.1186/s13321-017-0247-6
     * %[5] JRC QSAR Model Database https://qsardb.jrc.ec.europa.eu/qmrf/endpoint
     * </pre>
     *
     * @param nargout Number of outputs to return.
     * @param rhs The inputs to the MATLAB function.
     *
     * @return Array of length nargout containing the function outputs. Outputs are 
     * returned as sub-classes of <code>com.mathworks.toolbox.javabuilder.MWArray</code>. 
     * Each output array should be freed by calling its <code>dispose()</code> method.
     *
     * @throws java.rmi.RemoteException An error has occurred during the function call or 
     * in communication with the server.
     */
    public Object[] OPERA(int nargout, Object... rhs) throws RemoteException;
  
    /** 
     * Frees native resources associated with the remote server object 
     * @throws java.rmi.RemoteException An error has occurred during the function call or in communication with the server.
     */
    void dispose() throws RemoteException;
}
