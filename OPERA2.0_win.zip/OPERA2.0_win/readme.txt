OPERA Executable

1. Prerequisites for Deployment 

Verify that version 9.4 (R2018a) of the MATLAB Runtime is installed.   
If not, you can run the MATLAB Runtime installer.

NOTE: You will need administrator rights to run the MATLAB Runtime installer. 

. Run MyAppInstaller_web.exe to properly deploy OPERA (by default in C:\Program Files).
  This will take a few minutes to also download and install MATLAB Runtime (version 9.4 R2018a)
  if it's the first time to use a MATLAB deployed app. 

. Or download and install the Windows version of the MATLAB Runtime for R2018a 
from the following link on the MathWorks website:

    http://www.mathworks.com/products/compiler/mcr/index.html
   
For more information about the MATLAB Runtime and the MATLAB Runtime installer, see 
Package and Distribute in the MATLAB Compiler documentation  
in the MathWorks Documentation Center.

2. Application use

Files available for use by the Standalone App
================================
-This readme file 
-MyAppInstaller_web.exe to install the app. Run the app from command prompt (cmd) by navigating to its location or by adding it to your %PATH%.  
-Shortcut for OPERA. Use this to run the app by double-clicking from Desktop
 (or other location). This will run the app in your %HOMEPATH% as the working directory (can be changed from the shortcut properties).
-add2path.bat run as administrator to add OPERA to system %PATH% environment variable permanently.
-help.txt explains the different input and output arguments. Can be accessed from the app (-h command).
-splash.png the splash screen shown while loading the app. Can be renamed or deleted if not needed.
-icons can be used for creating new shortcuts.
-endpoints.txt list of available endpoints.
-install guide.pdf step-by-step guide to install the app.
-Sample_50.csv, Sample_50.sdf, Salt_info.csv Sample files for testing 





3. Definitions

For information on deployment terminology, go to
http://www.mathworks.com/help and select MATLAB Compiler >
Getting Started > About Application Deployment >
Deployment Product Terms in the MathWorks Documentation
Center.




